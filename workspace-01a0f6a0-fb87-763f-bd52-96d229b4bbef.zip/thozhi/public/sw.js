const CACHE = 'thozhi-v2.0.0-release';
const CORE = ['/', '/index.html', '/style.css', '/experience.css', '/hub.css', '/app.js', '/lib/scheme.js', '/lib/intent-model.js', '/lib/locales.js', '/lib/experience-ui.js', ...['hub','hub-ui','hub-services','learning-data','states','hub-router'].map(name=>`/lib/${name}.js`), '/lib/scheme-translations.js', '/lib/indic-intents.js', '/manifest.webmanifest', '/assets/logo.svg', '/assets/companion.svg', '/assets/images/independent-woman-4k.webp', '/assets/images/clean-kitchen-4k.webp', '/assets/images/independent-woman-mobile.webp', '/assets/icon-192.png', '/assets/icon-512.png', '/assets/fonts/dm-sans.woff2', '/assets/fonts/noto-tamil.woff2', ...['devanagari','telugu','kannada','malayalam','bengali'].map(script => `/assets/fonts/noto-${script}.woff2`), ...['hub-welcome', 'learn-welcome', 'welcome', 'adult', 'lpg', 'poor', 'documents', 'next', 'help', 'possible', 'review', 'confirm'].map(name => `/assets/audio/${name}.mp3`)];
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(names => Promise.all(names.filter(name => name.startsWith('thozhi-') && name !== CACHE).map(name => caches.delete(name)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    if (event.request.mode === 'navigate') {
      try { return await fetch(event.request); } catch { return (await cache.match('/index.html')) || Response.error(); }
    }
    const saved = await cache.match(event.request, { ignoreSearch: true });
    return saved || fetch(event.request);
  })());
});
