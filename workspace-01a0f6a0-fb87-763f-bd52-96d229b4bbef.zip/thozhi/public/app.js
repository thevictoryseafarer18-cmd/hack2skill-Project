import { createHub, HUB_URLS } from './lib/hub.js';
import { SCHEME, QUESTIONS, DOCUMENTS, FAQ, newJourney, answerQuestion, eligibility, makeChecklist } from './lib/scheme.js';
import { classifyIntent, detectAnswer, redactSensitive } from './lib/intent-model.js';

import { LANGUAGES, UI_TRANSLATIONS } from './lib/locales.js';

// Seven Indian languages plus Tanglish. Facts/rules are identical in every view.
const PATHS = {
  app: '<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 18h4M9 9h6m-3-3v6"/>',
  monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M12 17v4m-4 0h8"/>',
  check: '<path d="m5 12 4 4L19 6"/>', x: '<path d="m6 6 12 12M18 6 6 18"/>',
  arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>', back: '<path d="M19 12H5m6 6-6-6 6-6"/>',
  chevron: '<path d="m9 5 7 7-7 7"/>',
  mic: '<rect x="9" y="2.5" width="6" height="12" rx="3"/><path d="M5 10v1a7 7 0 0 0 14 0v-1M12 18v4m-4 0h8"/>',
  volume: '<path d="m11 4-6 5H2v6h3l6 5V4Zm4 4a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
  mute: '<path d="m11 4-6 5H2v6h3l6 5V4Zm5 5 6 6m0-6-6 6"/>',
  flame: '<path d="M13 2c1 6-4 6-3 10 2-1 3-3 4-4 3 3 5 5 5 8a7 7 0 0 1-14 0c0-5 7-6 8-14Z"/>',
  sparkle: '<path d="m12 3 2.3 6.7L21 12l-6.7 2.3L12 21l-2.3-6.7L3 12l6.7-2.3L12 3Zm7-1v4m-2-2h4"/>',
  heart: '<path d="M20.5 5.5a5 5 0 0 0-7 0L12 7l-1.5-1.5a5 5 0 0 0-7 7L12 21l8.5-8.5a5 5 0 0 0 0-7Z"/>',
  language: '<path d="M2 5h12M8 2v3m-4 0c0 5 3 8 8 10m0-10c-1 6-4 9-10 11m11 4 4-11 5 11m-7-4h6"/>',
  chat: '<path d="M21 11.5a8.5 8.5 0 0 1-9 8.5 10 10 0 0 1-4-.9L3 21l1.8-4.8A8.5 8.5 0 1 1 21 11.5Z"/><path d="M7 9h10M7 13h6"/>',
  shield: '<path d="m12 3 8 3v6c0 5-5 8-8 10-3-2-8-5-8-10V6l8-3Z"/><path d="m8 12 3 3 5-6"/>',
  verified: '<path d="m12 2 3 2 4 1 1 4 2 3-2 3-1 4-4 1-3 2-3-2-4-1-1-4-2-3 2-3 1-4 4-1 3-2Z"/><path d="m8 12 3 3 5-6"/>',
  lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4M12 14v3"/>',
  ear: '<path d="M7 13a7 7 0 1 1 12-1c-1 2-5 3-5 6a4 4 0 0 1-8 0m6-6c-3-6 4-8 5-3 0 2-3 2-3 4"/>',
  steps: '<path d="M2 19h6v-5h6V9h6V4h3M3 4h5m-2-2 2 2-2 2"/>',
  refresh: '<path d="M3 10a9 9 0 0 1 15-6l3 3M21 3v4h-4M21 14a9 9 0 0 1-15 6l-3-3M3 21v-4h4"/>',
  person: '<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  home: '<path d="m3 10 9-8 9 8v11H3V10Zm6 11v-8h6v8"/>',
  question: '<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 0 1 6 0c0 2-3 2-3 4m0 3h.01"/>',
  id: '<rect x="2" y="4" width="20" height="16" rx="2"/><circle cx="8" cy="10" r="2"/><path d="M4.5 17a3.5 3.5 0 0 1 7 0M14 9h5m-5 4h5m-5 4h3"/>',
  family: '<circle cx="9" cy="6" r="3"/><path d="M3 20v-3a6 6 0 0 1 12 0v3m2-17a3 3 0 0 1 0 6m0 3a5 5 0 0 1 5 5v3"/>',
  bank: '<path d="m2 8 10-6 10 6H2Zm1 13h18M5 11v7m7-7v7m7-7v7"/>',
  pin: '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
  file: '<path d="M14 2H5v20h14V7l-5-5Zm0 0v6h5M8 12h8m-8 4h8"/>',
  phone: '<path d="m5 3 4 1 1 5-3 2c2 3 3 4 6 6l2-3 5 1 1 4c-1 4-5 3-9 1C5 16-1 6 5 3Z"/>',
  shop: '<path d="M3 10h18l-2-7H5l-2 7Zm1 0v11h16V10M9 21v-7h6v7M3 10a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/>',
  globe: '<circle cx="12" cy="12" r="10"/><ellipse cx="12" cy="12" rx="4" ry="10"/><path d="M2 12h20M4 6h16M4 18h16"/>',
  download: '<path d="M12 3v12m-5-5 5 5 5-5M3 16v5h18v-5"/>',
  external: '<path d="M14 3h7v7m0-7L10 14m-1-11H3v18h18v-6"/>',
  pause: '<path d="M8 5v14M16 5v14"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>'
};
const $ = selector => document.querySelector(selector);
const esc = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icon = name => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${PATHS[name] || PATHS.info}</svg>`;
let lang = 'tl';
let hub = null;
const languageInfo = () => LANGUAGES.find(item => item.id === lang);
const t = key => UI_TRANSLATIONS[lang]?.[key] || key;
const localized = value => value?.[lang] || '';
let state = newJourney();
let history = [];
let soundEnabled = true;
let lastFAQ = null;
let pending = null;
let modelMode = 'local';
let busy = false;
let externalConsent = false;
let pendingExternalText = null;
let recording = false;
let recognition = null;
let recordTimer;
let toastTimer;
let speaking = false;
let modalClip = null;
let speechTicket = 0;
let installPrompt = null;
let installedThisSession = false;
const audio = new Audio();
audio.preload = 'none';
const allowedURLs = new Set([...HUB_URLS, SCHEME.source, SCHEME.home, SCHEME.kyc, ...SCHEME.providers.flatMap(p => [p.apply, p.locate]).filter(Boolean)]);

function hydrateIcons(root = document) { root.querySelectorAll('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); }); }
function localizePage() {
  document.documentElement.lang = languageInfo().locale;
  document.documentElement.dataset.language = lang;
  document.title = `Thozhi — ${t('heroOne')} ${t('heroTwo')}`;
  document.querySelectorAll('[data-i18n]').forEach(el => { el.innerHTML = t(el.dataset.i18n); });
  $('#question-input').placeholder = t('questionPlaceholder');
  $('#language').value = lang;
  $('#audio-toggle').setAttribute('aria-label', soundEnabled ? t('soundOn') : t('soundOff'));
  $('#guide').setAttribute('aria-label', t('serviceTitle'));
  $('#progress').setAttribute('aria-label', t('progressTitle'));
  $('.language-control .sr-only').textContent = t('chooseLanguage');
  $('.header-actions').setAttribute('aria-label', t('chooseLanguage'));
  $('.brand').setAttribute('aria-label', t('yourThozhi'));
  $('.hero-illustration').alt = t('imageAlt');
  $('.mini-mic').setAttribute('aria-label', t('tapSpeak'));
  $('.send-button').setAttribute('aria-label', t('sendQuestion'));
  $('.reassurance-bar').setAttribute('aria-label', t('helpTitle'));
  $('#voice-mode').innerHTML = icon('ear') + esc(t(languageInfo().bundled ? 'audioBuiltIn' : 'audioDevice'));
  $('#app-nav').setAttribute('aria-label', `Thozhi · ${t('navGuide')} · ${t('navLanguage')} · ${t('navHelp')}`);
  syncPlatform();
  renderLanguageGarden();
  syncSoundUI();
  hydrateIcons();
}
function languageChoicesHTML() {
  return LANGUAGES.map(item => `<button type="button" lang="${item.locale}" class="language-tile tone-${item.tone} ${item.id === lang ? 'selected' : ''}" data-action="switch-language" data-lang="${item.id}" aria-pressed="${item.id === lang}" aria-label="${esc(item.nativeName)}"><span class="language-glyph" aria-hidden="true">${item.glyph}</span><span class="language-tile-copy"><strong lang="${item.locale}">${esc(item.nativeName)}</strong><small lang="${item.locale}">${esc(item.greeting)}</small></span>${item.id === lang ? `<span class="language-picked">${icon('check')}</span>` : ''}</button>`).join('');
}
function renderLanguageGarden() {
  $('#language-list').innerHTML = languageChoicesHTML();
}
function setLanguage(id) {
  if (!LANGUAGES.some(item => item.id === id)) return;
  cancelListening(); stopAudio(); clearFeedback(); lang = id;
  localizePage(); if (hub?.mode === 'gas') render({ clear: false }); else hub?.render(); updateConnectivity();
  if ($('#modal').open) $('#modal').close();
}
function showLanguages() {
  modalShell(`<div class="modal-eyebrow">THOZHI · 7 + TANGLISH</div><h2 id="modal-title">${t('languagesTitle')}</h2><p class="modal-copy">${t('languagesCopy')}</p><div class="language-grid modal-languages">${languageChoicesHTML()}</div><p class="mode-note">${t(languageInfo().bundled ? 'audioBuiltIn' : 'audioDevice')}</p>`);
}
function syncSoundUI() {
  const button = $('#audio-toggle');
  button.setAttribute('aria-pressed', String(soundEnabled));
  button.innerHTML = icon(soundEnabled ? 'volume' : 'mute') + `<span>${t(soundEnabled ? 'soundOn' : 'soundOff')}</span>`;
  const listen = $('.guide-toolbar .listen-button');
  listen.innerHTML = icon(speaking ? 'pause' : 'volume') + `<span>${t(speaking ? 'stop' : 'listen')}</span>`;
  listen.classList.toggle('speaking', speaking);
}
function renderProgress() {
  const step = { welcome: 0, questions: 1, outcome: 1, documents: 2, next: 3 }[state.phase];
  $('#progress').innerHTML = ['introStep', 'eligibilityStep', 'documentsStep', 'nextStep'].map((key, idx) => `<li class="${idx === step ? 'current' : idx < step ? 'done' : ''}" ${idx === step ? 'aria-current="step"' : ''}><span class="progress-number">${idx < step ? icon('check') : idx + 1}</span><span>${t(key)}</span></li>`).join('');
}
function micButton() {
  return `<button type="button" class="mic-button" data-action="mic"><span class="mic-circle">${icon('mic')}</span><span><strong>${t('tapSpeak')}</strong><small>${t('sayStart')}</small></span>${icon('arrow')}</button>`;
}
function bottomControls() {
  return `<div class="stage-bottom"><button type="button" class="back-button" data-action="back">${icon('back')}${t('back')}</button><button type="button" class="speak-small" data-action="mic">${icon('mic')}${t('answerByVoice')}</button></div>`;
}
function welcomeHTML() {
  return `<div class="greeting"><h3 id="stage-title" tabindex="-1">${t('welcomeTitle')} <span class="wave-emoji" aria-hidden="true">👋</span></h3><p class="welcome-full">${t('welcomeCopy')}</p><p class="welcome-brief">${t('welcomeBrief')}</p></div>${micButton()}<button type="button" class="manual-button" data-action="start">${t('startWithoutVoice')}${icon('arrow')}</button><div class="starter-label">${t('orAsk')}</div><div class="starter-chips"><button type="button" data-action="faq" data-intent="eligibility">${t('askEligibility')}</button><button type="button" data-action="faq" data-intent="documents">${t('askDocs')}</button><button type="button" data-action="faq" data-intent="language">${t('askLanguage')}</button></div>`;
}
function questionHTML() {
  const q = QUESTIONS[state.question];
  return `<div class="stage-eyebrow"><span>${t('questionCount')} ${state.question + 1} / ${QUESTIONS.length}</span><span>PMUY</span></div><div class="question-visual">${icon(q.icon)}</div><h3 class="question-title" id="stage-title" tabindex="-1">${esc(localized(q.title))}</h3><p class="question-note">${esc(localized(q.note))}</p><div class="choice-row"><button type="button" class="answer-button yes" data-action="answer" data-value="yes">${icon('check')}${t('yes')}</button><button type="button" class="answer-button no" data-action="answer" data-value="no">${icon('x')}${t('no')}</button></div><button type="button" class="unsure-button" data-action="answer" data-value="unsure">${icon('question')}${t('unsure')}</button>${bottomControls()}`;
}
function outcomeHTML() {
  const result = eligibility(state.answers);
  const good = result === 'potential';
  const title = good ? 'possibleTitle' : result === 'confirm' ? 'confirmTitle' : 'notEligibleTitle';
  const reasons = [];
  if (state.answers.adult === 'no') reasons.push(t('adultFail'));
  if (state.answers.lpg === 'yes') reasons.push(t('lpgFail'));
  if (state.answers.poor === 'no') reasons.push(t('poorFail'));
  const copy = good ? t('possibleCopy') : result === 'confirm' ? t('confirmCopy') : reasons.map(esc).join('<br><br>');
  return `<div class="outcome"><div class="outcome-icon ${good ? '' : 'caution'}">${icon(good ? 'check' : 'info')}</div><h3 class="question-title" id="stage-title" tabindex="-1">${t(title)}</h3><p class="question-note">${copy}</p><div class="result-note">${t(good ? 'possibleNote' : 'canReview')}</div><div class="button-stack">${!good ? `<a class="phone-link" href="tel:${SCHEME.helpline}">${icon('phone')}${t('callHelp')}</a>` : ''}<button type="button" class="${good ? 'primary-button' : 'secondary-button'}" data-action="documents">${t(good ? 'seeDocuments' : 'seeDocsAnyway')}${icon('arrow')}</button></div></div>${bottomControls()}`;
}
function documentsHTML() {
  return `<div class="stage-eyebrow"><span>${t('documentsStep')}</span><span>${state.ready.length} / ${DOCUMENTS.length}</span></div><h3 class="question-title" id="stage-title" tabindex="-1">${t('documentsTitle')}</h3><p class="question-note">${t('documentsCopy')}</p><div class="document-list">${DOCUMENTS.map(d => `<div class="document-item"><label class="document-label" for="doc-${d.id}">${icon(d.icon)}<span>${esc(localized(d.name))}</span><input type="checkbox" id="doc-${d.id}" data-document="${d.id}" ${state.ready.includes(d.id) ? 'checked' : ''} aria-label="${esc(localized(d.name))}"></label><details><summary>${t('explain')}</summary><p>${esc(localized(d.detail))}</p></details></div>`).join('')}</div><p class="check-note">${t('docsNotReady')}</p><button type="button" class="primary-button" data-action="next">${t('goNext')}${icon('arrow')}</button>${bottomControls()}`;
}
function nextHTML() {
  return `<div class="completed-flag">${icon('check')}${t('pathReady')}</div><h3 class="question-title" id="stage-title" tabindex="-1">${t('finalTitle')}</h3><p class="question-note">${t('finalCopy')}</p><button type="button" class="route-card" data-action="route"><span class="route-icon">${icon('shop')}</span><span><strong>${t('offlineRoute')}</strong><small>${t('offlineRouteDetail')}</small></span>${icon('arrow')}</button><button type="button" class="route-card online-route" data-action="external" data-url="${SCHEME.source}"><span class="route-icon">${icon('globe')}</span><span><strong>${t('onlineRoute')}</strong><small>${t('onlineRouteDetail')}</small></span>${icon('external')}</button><p class="completion-note">${t('notSubmitted')}</p><button type="button" class="download-button" data-action="download">${icon('download')}${t('saveChecklist')}</button>${bottomControls()}`;
}
function render({ focus = false, clear = true } = {}) {
  document.body.dataset.phase = state.phase;
  renderProgress();
  $('#stage').innerHTML = ({ welcome: welcomeHTML, questions: questionHTML, outcome: outcomeHTML, documents: documentsHTML, next: nextHTML })[state.phase]();
  if (clear) { clearFeedback(); lastFAQ = null; $('#faq-answer').hidden = true; }
  else if (lastFAQ) renderFAQ();
  syncSoundUI();
  updateMicUI();
  if (focus) {
    $('#stage-title')?.focus({ preventScroll: true });
    if (window.matchMedia('(max-width:760px)').matches) $('#guide').scrollIntoView({ block: 'start', behavior: 'instant' });
  }
}
function changeState(next, { speak = true } = {}) {
  cancelListening();
  stopAudio();
  history.push(structuredClone(state));
  state = next;
  render({ focus: true });
  if (speak && soundEnabled) speakCurrent();
}
function startGuide() { changeState({ ...newJourney(), phase: 'questions' }); }
function goBack() {
  if (!history.length) return;
  cancelListening(); stopAudio();
  state = history.pop();
  render({ focus: true });
  if (soundEnabled) speakCurrent();
}
function clearFeedback() { pending = null; $('#voice-feedback').hidden = true; $('#voice-feedback').innerHTML = ''; const h=$('#hub-feedback'); if(h){h.hidden=true;h.innerHTML='';} }
function feedback(message, { html = false } = {}) {
  const area = hub?.mode !== 'gas' && $('#hub-feedback') ? $('#hub-feedback') : $('#voice-feedback'); area.innerHTML = html ? message : esc(message); area.hidden = false;
}
function toast(message) {
  clearTimeout(toastTimer); const area = $('#toast'); area.textContent = message; area.hidden = false;
  toastTimer = setTimeout(() => { area.hidden = true; }, 5500);
}

function setSpeaking(value) { speaking = value; syncSoundUI(); document.querySelectorAll('[data-hub-action="listen"]').forEach(b=>{b.classList.toggle('speaking',value);b.setAttribute('aria-pressed',String(value));b.innerHTML=icon(value?'pause':'volume')+esc(t(value?'stop':'listen'));}); }
function stopAudio() {
  speechTicket += 1;
  audio.pause(); audio.currentTime = 0;
  window.speechSynthesis?.cancel(); setSpeaking(false);
}
audio.addEventListener('ended', () => setSpeaking(false));
audio.addEventListener('error', () => { setSpeaking(false); toast(t('audioBlocked')); });
function nativeSpeech(value) { return value?.[lang === 'tl' ? 'ta' : lang] || ''; }
function clipNarration(clip) {
  const speechLang = lang === 'tl' ? 'ta' : lang;
  const u = key => UI_TRANSLATIONS[speechLang][key];
  const choices = `${u('yes')}. ${u('no')}. ${u('unsure')}.`;
  if (clip === 'welcome') return `${u('welcomeTitle')} ${u('welcomeCopy')} ${u('inputSafety')} ${u('startWithoutVoice')}.`;
  const q = QUESTIONS.find(item => item.clip === clip);
  if (q) return `${nativeSpeech(q.title)} ${nativeSpeech(q.note)} ${choices}`;
  if (clip === 'documents') return `${u('documentsTitle')} ${u('documentsCopy')} ` + DOCUMENTS.map(d => `${nativeSpeech(d.name)}. ${nativeSpeech(d.detail)}`).join(' ');
  if (clip === 'next') return `${u('finalCopy')} ${u('offlineRoute')}. ${u('offlineRouteDetail')} ${u('onlineRoute')}. ${u('notSubmitted')}`;
  if (clip === 'possible') return `${u('possibleCopy')} ${u('possibleNote')} ${u('seeDocuments')}.`;
  if (clip === 'review') return `${u('canReview')} ${u('adultFail')} ${u('lpgFail')} ${u('poorFail')}`;
  if (clip === 'confirm') {
    const answer = pending?.action === 'start' ? u('startWithoutVoice') : pending?.value ? u({yes:'yes',no:'no',unsure:'unsure'}[pending.value]) : '';
    return `${u('confirmHeard')} ${answer}. ${u('confirmYes')}. ${u('confirmNo')}.`;
  }
  return `${u('helpIntro')} ${u('howOneCopy')} ${u('howTwoCopy')} ${u('howThreeCopy')} ${u('inputSafety')} ${u('phoneSpeech')}`;
}
function matchingVoice() {
  const prefix = languageInfo().voicePrefix;
  return window.speechSynthesis?.getVoices().find(v => v.lang?.toLowerCase().replace('_','-').split('-')[0] === prefix);
}
async function waitForNativeVoice() {
  if (matchingVoice()) return matchingVoice();
  if (!window.speechSynthesis) return null;
  // Some browsers populate voices asynchronously; never fall back to an English voice.
  await new Promise(resolve => {
    const ready = () => { clearTimeout(timer); window.speechSynthesis.removeEventListener('voiceschanged', ready); resolve(); };
    const timer = setTimeout(ready, 800);
    window.speechSynthesis.addEventListener('voiceschanged', ready, { once: true });
  });
  return matchingVoice() || null;
}
async function speak(clip, translatedText) {
  stopAudio();
  const ticket = speechTicket;
  if (clip && languageInfo().bundled) {
    audio.src = `/assets/audio/${clip}.mp3`;
    setSpeaking(true);
    audio.play().catch(() => { if (ticket === speechTicket) { setSpeaking(false); toast(t('audioBlocked')); } });
    return;
  }
  const text = (translatedText || clipNarration(clip)).replace(/<[^>]*>/g, ' ');
  const voice = await waitForNativeVoice();
  if (ticket !== speechTicket) return;
  if (!voice || !text) { toast(t('noTamilVoice')); return; }
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = languageInfo().speech; utterance.voice = voice; utterance.rate = 0.88;
  utterance.onend = () => { if (ticket === speechTicket) setSpeaking(false); };
  utterance.onerror = () => { if (ticket === speechTicket) { setSpeaking(false); toast(t('audioBlocked')); } };
  setSpeaking(true); window.speechSynthesis.speak(utterance);
}
function speakCurrent() {
  if (hub && hub.mode !== 'gas') { hub.narration(); return; }
  if (state.phase === 'welcome') speak('welcome');
  else if (state.phase === 'questions') speak(QUESTIONS[state.question].clip);
  else if (state.phase === 'documents') speak('documents');
  else if (state.phase === 'next') speak('next');
  else speak(eligibility(state.answers) === 'potential' ? 'possible' : 'review');
}

function updateMicUI() {
  document.querySelectorAll('[data-action="mic"], [data-action="ask-mic"], [data-hub-action="mic"]').forEach(button => {
    button.classList.toggle('recording', recording); button.setAttribute('aria-pressed', String(recording));
    button.setAttribute('aria-label', t(recording ? 'stopListening' : 'tapSpeak'));
    const mainLabel = button.querySelector('strong');
    if (mainLabel) mainLabel.textContent = t(recording ? 'listening' : 'tapSpeak');
  });
}
function cancelListening() {
  clearTimeout(recordTimer);
  if (recognition) { recognition._cancelled = true; try { recognition.abort(); } catch {} }
  recognition = null; recording = false; updateMicUI();
}
function microphoneFallback(key) {
  feedback(t(key));
  if (soundEnabled) { if(hub?.mode !== 'gas') hub?.narration(); else speak('help'); }
  if (window.matchMedia('(max-width:760px)').matches) {
    $('#stage').querySelector('.manual-button, .answer-button')?.scrollIntoView({ block: 'center', behavior: 'instant' });
  }
}
function startListening(purpose = 'guide') {
  if (recording) { recognition?.stop(); return; }
  stopAudio();
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition || !window.isSecureContext) { microphoneFallback('micUnsupported'); return; }
  if (!navigator.onLine) { microphoneFallback('micNetwork'); return; }
  clearFeedback();
  const session = new SpeechRecognition();
  recognition = session;
  session.lang = languageInfo().speech; session.continuous = false; session.interimResults = false; session.maxAlternatives = 1;
  let heard = false; let failed = false;
  session.onstart = () => {
    recording = true; updateMicUI();
    feedback(`<span class="wave-indicator" aria-hidden="true"><span></span><span></span><span></span><span></span></span>${esc(t('listening'))}`, { html: true });
    recordTimer = setTimeout(() => { try { session.stop(); } catch {} }, 16000);
  };
  session.onresult = event => {
    if (session._cancelled) return;
    heard = true; recording = false; updateMicUI();
    clearTimeout(recordTimer);
    const text = event.results[event.results.length - 1]?.[0]?.transcript || '';
    askQuestion(text, { allowAnswer: purpose === 'guide' });
  };
  session.onerror = event => {
    if (session._cancelled) return;
    failed = true; recording = false; updateMicUI();
    const key = ['not-allowed', 'service-not-allowed'].includes(event.error) ? 'micDenied' : event.error === 'network' ? 'micNetwork' : 'micNoSpeech';
    microphoneFallback(key);
  };
  session.onend = () => {
    clearTimeout(recordTimer);
    if (recognition === session) recognition = null;
    recording = false; updateMicUI();
    if (!heard && !failed && !session._cancelled) feedback(t('micNoSpeech'));
  };
  try { session.start(); } catch { recording = false; microphoneFallback('micUnsupported'); updateMicUI(); }
}

function confirmAnswer(value, transcript, action = 'answer') {
  pending = { value, action, question: state.phase === 'questions' ? QUESTIONS[state.question].id : null };
  const inferred = action === 'start' ? t('startWithoutVoice') : t({ yes: 'yes', no: 'no', unsure: 'unsure' }[value]);
  feedback(`<strong>${esc(t('confirmHeard'))}</strong><p class="transcript">“${esc(transcript)}”</p><p>${esc(t('understoodAs'))} <strong>${esc(inferred)}</strong></p><div class="confirmation-buttons"><button type="button" data-action="confirm-answer">${esc(t('confirmYes'))}</button><button type="button" data-action="reject-answer">${esc(t('confirmNo'))}</button></div>`, { html: true });
  if (soundEnabled) speak('confirm');
}
async function askQuestion(raw, { allowAnswer = true } = {}) {
  if (busy) return;
  const text = redactSensitive(raw.trim());
  if (!text) return;
  if (text !== raw.trim()) toast(t('privacyRedacted'));
  if (hub && hub.mode !== 'gas') {
    if (classifyIntent(text).intent === 'emergency') { hub.show('gas'); showFAQ('emergency'); }
    else hub.onQuery(text);
    return;
  }
  if (allowAnswer && state.phase === 'questions') {
    const answer = detectAnswer(text, QUESTIONS[state.question].id);
    if (answer) { confirmAnswer(answer, text); return; }
  }
  let match = classifyIntent(text);
  if (allowAnswer && state.phase === 'welcome' && (detectAnswer(text, 'start') === 'yes' || match.intent === 'start')) {
    confirmAnswer(null, text, 'start'); return;
  }
  // Most questions never leave this device. Server assistance is opt-in deployment
  // configuration, exposed in the privacy/help panel, and only for unknown intents.
  if (match.intent === 'unknown' && modelMode === 'hybrid' && navigator.onLine) {
    if (!externalConsent) { showAIConsent(text); return; }
    busy = true; $('#question-form').setAttribute('aria-busy', 'true'); feedback(t('aiThinking'));
    try {
      const response = await fetch('/api/assist', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, allowExternal: true }), signal: AbortSignal.timeout(8500) });
      if (response.ok) { const result = await response.json(); if (typeof result.intent === 'string') match = result; }
    } catch { /* Offline or service failure: use the safe local unknown response. */ }
    finally { busy = false; $('#question-form').removeAttribute('aria-busy'); }
  }
  clearFeedback();
  handleIntent(match.intent);
}
function handleIntent(intent) {
  if (intent === 'proceed') {
    if (state.phase === 'welcome') startGuide();
    else if (state.phase === 'questions') { feedback(t('questionNoSkip')); if (soundEnabled) speakCurrent(); }
    else if (state.phase === 'outcome') changeState({ ...state, phase: 'documents' });
    else if (state.phase === 'documents') changeState({ ...state, phase: 'next' });
    else showRoute();
    return;
  }
  if (intent === 'route') { if (state.phase === 'next') showRoute(); else showFAQ('apply'); return; }
  if (intent === 'save') { if (state.phase === 'next') downloadChecklist(); else showFAQ('documents'); return; }
  if (intent === 'apply' && state.phase === 'next') { showExternal(SCHEME.source); return; }
  if (intent === 'repeat') { speakCurrent(); return; }
  if (intent === 'back') { goBack(); return; }
  if (intent === 'reset') { showRestart(); return; }
  if (intent === 'start') { if (state.phase === 'welcome') startGuide(); else showFAQ('apply'); return; }
  showFAQ(FAQ[intent] ? intent : 'unknown');
}
function showFAQ(intent) {
  lastFAQ = intent;
  renderFAQ();
  if (soundEnabled && FAQ[intent]?.clip) speak(FAQ[intent].clip, nativeSpeech(FAQ[intent].text));
}
function renderFAQ() {
  const item = FAQ[lastFAQ]; const area = $('#faq-answer'); area.hidden = false;
  area.innerHTML = `<button type="button" class="faq-close" data-action="close-faq" aria-label="${esc(t('close'))}">${icon('x')}</button><h4>${item ? esc(localized(item.title)) : t('unknownTitle')}</h4><p>${item ? esc(localized(item.text)) : t('unknownCopy')}</p>${item ? `<div class="faq-controls"><button type="button" data-action="listen-faq">${icon('volume')}${t('faqListen')}</button>${item.source ? `<button type="button" data-action="external" data-url="${item.source}">${t('officialSource')}${icon('external')}</button>` : ''}</div>` : `<div class="faq-suggestions"><button type="button" data-action="faq" data-intent="eligibility">${t('askEligibility')}</button><button type="button" data-action="faq" data-intent="documents">${t('askDocs')}</button><button type="button" data-action="faq" data-intent="apply">${t('nextStep')}</button></div>`}`;
}
function setAskOpen(value) {
  const button = $('.ask-toggle'); button.setAttribute('aria-expanded', String(value)); $('#question-form').hidden = !value;
  if (value) $('#question-input').focus({ preventScroll: true });
}

function modalShell(content, clip = null) {
  cancelListening(); stopAudio(); modalClip = clip;
  $('#modal-content').innerHTML = `<div class="modal-body"><button type="button" class="modal-close" data-action="close-modal" aria-label="${esc(t('close'))}">${icon('x')}</button>${content}</div>`;
  $('#modal').setAttribute('aria-labelledby', 'modal-title');
  if (!$('#modal').open) $('#modal').showModal();
}
function listenModalButton() { return `<button type="button" class="listen-button" data-action="listen-modal">${icon('volume')}${t('listen')}</button>`; }
function showHow() {
  if(hub && hub.mode !== 'gas') { modalShell(`<h2 id="modal-title">${t('helpTitle')}</h2><p class="modal-copy">${esc(hub.helpText())}</p><div class="button-stack"><button type="button" class="primary-button" data-hub-action="view" data-view="learn">${esc(hub.ui('goLearn'))}${icon('steps')}</button><button type="button" class="secondary-button" data-action="install">${t('installShort')}${icon('app')}</button></div><p class="mode-note">${t('modelNote')}</p>`, 'hub-welcome'); return; }
  modalShell(`<div class="modal-eyebrow">THOZHI · ${t('brandTag')}</div><h2 id="modal-title">${t('helpTitle')}</h2><p class="modal-copy">${t('helpIntro')}</p>${listenModalButton()}<div class="how-list">${['One', 'Two', 'Three'].map((number, index) => `<div><span class="how-number">${index + 1}</span><div><strong>${t('how' + number)}</strong><p>${t('how' + number + 'Copy')}</p></div></div>`).join('')}</div><p class="mode-note">${t(modelMode === 'hybrid' ? 'hybridNote' : 'modelNote')}</p><button type="button" class="primary-button" data-action="close-modal">${t('okay')}${icon('check')}</button>`, 'help');
}
function showPrivacy() {
  modalShell(`<div class="modal-eyebrow">THOZHI · ${t('safeLine')}</div><h2 id="modal-title">${esc(localized(FAQ.privacy.title))}</h2><p class="modal-copy">${esc(localized(FAQ.privacy.text))}</p>${listenModalButton()}<p class="mode-note">${t(modelMode === 'hybrid' ? 'hybridNote' : 'modelNote')}</p><button type="button" class="primary-button" data-action="close-modal">${t('okay')}${icon('shield')}</button>`, 'help');
}
function showSources() {
  if(hub && hub.mode !== 'gas') { modalShell(`<h2 id="modal-title">${t('sourceTitle')}</h2><p class="modal-copy">${esc(hub.ui('ruleNote'))}</p>${[['iGOD','https://igod.gov.in/sg/states'],['myScheme','https://www.myscheme.gov.in/'],['NIELIT','https://www.nielit.gov.in/NielitMain/HQ'],['CERT-In','https://www.cert-in.org.in/PDF/Mahila_Suraksha_Booklet25.pdf']].map(([name,url])=>`<button type="button" class="source-card" data-action="external" data-url="${url}"><strong>${name}${icon('external')}</strong><p>${new URL(url).hostname}</p></button>`).join('')}<p class="source-date">${t('checked')}</p>`); return; }
  modalShell(`<div class="modal-eyebrow">${t('verified')}</div><h2 id="modal-title">${t('sourceTitle')}</h2><p class="modal-copy">${t('sourceCopy')}</p><button type="button" class="source-card" data-action="external" data-url="${SCHEME.source}"><strong>${t('sourceEligibility')}${icon('external')}</strong><p>pmuy.gov.in/ujjwala2.html</p></button><button type="button" class="source-card" data-action="external" data-url="${SCHEME.home}"><strong>${t('sourceHome')}${icon('external')}</strong><p>pmuy.gov.in</p></button><p class="source-date">${t('checked')}</p><button type="button" class="primary-button" data-action="close-modal">${t('okay')}</button>`);
}
function showAIConsent(text) {
  pendingExternalText = text;
  modalShell(`<div class="modal-eyebrow">${t('aiConsentTitle')}</div><h2 id="modal-title">${t('aiConsentTitle')}</h2><p class="modal-copy">${t('aiConsentCopy')}</p><div class="button-stack"><button type="button" class="primary-button" data-action="accept-ai">${t('aiConsentAccept')}</button><button type="button" class="secondary-button" data-action="decline-ai">${t('aiConsentDecline')}</button></div>`);
}
function syncPlatform() {
  const installed = installedThisSession || window.matchMedia('(display-mode:standalone)').matches || navigator.standalone === true;
  document.body.classList.toggle('is-installed', installed);
  document.body.dataset.installable = String(Boolean(installPrompt));
}
function showInstall() {
  const embeddedDemo = !['https:', 'http:'].includes(location.protocol);
  modalShell(`<div class="install-art" aria-hidden="true">${icon('app')}<img src="/assets/logo.svg" alt="" width="42" height="42"></div><h2 id="modal-title">${t(document.body.classList.contains('is-installed') ? 'appInstalled' : 'installTitle')}</h2><p class="modal-copy">${t('installCopy')}</p>${installPrompt ? `<button type="button" class="primary-button" data-action="install-now">${t('installNow')}${icon('download')}</button>` : ''}${embeddedDemo ? `<p class="mode-note">${t('installDemoNote')}</p>` : ''}<div class="install-instructions"><section><span class="install-step-number">1</span><div><h3>${t('installAndroid')}</h3><p>${t('installAndroidCopy')}</p></div></section><section><span class="install-step-number">2</span><div><h3>${t('installIOS')}</h3><p>${t('installIOSCopy')}</p></div></section></div><button class="secondary-button" type="button" data-action="close-modal">${t('okay')}</button>`);
}
async function installApp() {
  if (!installPrompt) { showInstall(); return; }
  const event = installPrompt; installPrompt = null; syncPlatform();
  try {
    await event.prompt();
    const result = await event.userChoice;
    if (result?.outcome === 'accepted') $('#modal').close();
    else toast(t('installCancelled'));
  } catch { toast(t('installCancelled')); }
}
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; syncPlatform(); });
window.addEventListener('appinstalled', () => { installedThisSession = true; installPrompt = null; syncPlatform(); toast(t('appInstalled')); });
window.matchMedia('(display-mode:standalone)').addEventListener?.('change', syncPlatform);

function showRestart() {
  modalShell(`<h2 id="modal-title">${t('restartTitle')}</h2><p class="modal-copy">${t('restartCopy')}</p><div class="modal-actions"><button type="button" class="secondary-button" data-action="close-modal">${t('cancel')}</button><button type="button" class="primary-button" data-action="confirm-restart">${t('restart')}${icon('refresh')}</button></div>`);
}
function showRoute() {
  modalShell(`<div class="modal-eyebrow">${t('nextStep')}</div><h2 id="modal-title">${t('routeTitle')}</h2><p class="modal-copy">${t('routeCopy')}</p>${listenModalButton()}<ol class="route-steps"><li>${t('routeOne')}</li><li>${t('routeTwo')}</li><li>${t('routeThree')}</li></ol><h3 style="font-size:13px;font-weight:600">${t('findAgency')}</h3>${SCHEME.providers.filter(p => p.locate).map(p => `<button type="button" class="source-card" data-action="external" data-url="${p.locate}"><strong>${esc(p.name)}${icon('external')}</strong><p>${esc(new URL(p.locate).hostname)}</p></button>`).join('')}<a class="phone-link" href="tel:${SCHEME.helpline}">${icon('phone')}${t('callHelp')}</a><button type="button" class="primary-button" data-action="download">${icon('download')}${t('saveChecklist')}</button>`, 'next');
}
function showExternal(url) {
  if (!allowedURLs.has(url)) return;
  const domain = new URL(url).hostname;
  if(hub && hub.mode !== 'gas') { modalShell(`<div class="modal-eyebrow">${t('officialSource')} · ${esc(domain)}</div><h2 id="modal-title">${t('externalTitle')}</h2><p class="modal-copy">${t('externalCopy')}</p><div class="external-domain">${icon('lock')}${esc(domain)}</div><p class="external-warning">${esc(hub.ui('ruleNote'))} ${t('inputSafety')}</p>${!navigator.onLine?`<p class="modal-copy">${t('internetRequired')}</p>`:''}<div class="button-stack">${navigator.onLine?`<a class="primary-button" href="${esc(url)}" target="_blank" rel="noopener noreferrer" data-action="opened-external">${t('openOfficial')}${icon('external')}</a>`:`<button type="button" class="primary-button" data-hub-action="save-study">${esc(hub.ui('saveStudy'))}</button>`}<button type="button" class="secondary-button" data-action="close-modal">${t('back')}</button></div>`); return; }
  modalShell(`<div class="modal-eyebrow">${t('officialSource')} · ${esc(domain)}</div><h2 id="modal-title">${t('externalTitle')}</h2><p class="modal-copy">${t('externalCopy')}</p><div class="external-domain">${icon('lock')}${esc(domain)}</div><p class="external-warning">${t('externalWarning')}</p>${!navigator.onLine ? `<p class="modal-copy">${t('internetRequired')}</p>` : ''}<div class="button-stack">${navigator.onLine ? `<a class="primary-button" href="${esc(url)}" target="_blank" rel="noopener noreferrer" data-action="opened-external">${t('openOfficial')}${icon('external')}</a>` : `<button type="button" class="primary-button" data-action="download">${icon('download')}${t('saveChecklist')}</button>`}<button type="button" class="secondary-button" data-action="close-modal">${t('back')}</button></div>`);
}
function downloadChecklist() {
  const blob = new Blob(['\ufeff', makeChecklist(state, lang)], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob); const anchor = document.createElement('a');
  anchor.href = url; anchor.download = 'thozhi-en-adutha-padi.txt';
  document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000);
  toast(t('downloaded'));
}

// Event delegation keeps every screen's controls consistent, including mobile.
document.addEventListener('click', event => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const action = button.dataset.action;
  if (button.tagName !== 'A') event.preventDefault();
  switch (action) {
    case 'start': startGuide(); break;
    case 'answer': changeState(answerQuestion(state, button.dataset.value)); break;
    case 'documents': changeState({ ...state, phase: 'documents' }); break;
    case 'next': changeState({ ...state, phase: 'next' }); break;
    case 'back': goBack(); break;
    case 'mic': startListening('guide'); break;
    case 'ask-mic': startListening('question'); break;
    case 'listen': if (speaking) stopAudio(); else speakCurrent(); break;
    case 'toggle-sound': soundEnabled = !soundEnabled; if (!soundEnabled) stopAudio(); syncSoundUI(); break;
    case 'confirm-answer': {
      if (!pending) break;
      const accepted = pending; clearFeedback();
      if (accepted.action === 'start' && state.phase === 'welcome') startGuide();
      else if (state.phase === 'questions' && accepted.question === QUESTIONS[state.question].id) changeState(answerQuestion(state, accepted.value));
      break;
    }
    case 'reject-answer': stopAudio(); clearFeedback(); feedback(t('micNoSpeech')); break;
    case 'faq': showFAQ(button.dataset.intent); break;
    case 'close-faq': lastFAQ = null; $('#faq-answer').hidden = true; stopAudio(); break;
    case 'listen-faq': if (lastFAQ && FAQ[lastFAQ]) speak(FAQ[lastFAQ].clip, nativeSpeech(FAQ[lastFAQ].text)); break;
    case 'toggle-ask': setAskOpen($('#question-form').hidden); break;
    case 'focus-guide': if(hub && hub.mode !== 'gas'){hub.show('hub');break;} $('#guide').scrollIntoView({ block: 'start', behavior: 'instant' }); $('#stage-title')?.focus({ preventScroll: true }); break;
    case 'install': showInstall(); break;
    case 'install-now': void installApp(); break;
    case 'nav-languages': showLanguages(); break;
    case 'nav-help': showHow(); break;
    case 'languages': showLanguages(); break;
    case 'switch-language':
      setLanguage(button.dataset.lang); if(hub?.mode==='gas'){ $('#guide').scrollIntoView({ block: 'start', behavior: 'instant' }); $('#stage-title')?.focus({ preventScroll: true }); } else { window.scrollTo({top:0,behavior:'instant'}); $('#hub-title')?.focus({preventScroll:true}); } break;
    case 'how': showHow(); break;
    case 'privacy': showPrivacy(); break;
    case 'sources': showSources(); break;
    case 'restart': showRestart(); break;
    case 'confirm-restart':
      cancelListening(); stopAudio(); state = newJourney(); history = []; lastFAQ = null; externalConsent = false; pendingExternalText = null;
      $('#question-input').value = ''; setAskOpen(false); $('#modal').close(); if(hub?.mode==='gas') render({ focus: true }); else hub?.show('hub'); break;
    case 'close-modal': pendingExternalText = null; $('#modal').close(); stopAudio(); break;
    case 'accept-ai': {
      const text = pendingExternalText; pendingExternalText = null; externalConsent = true; $('#modal').close();
      if (text) askQuestion(text, { allowAnswer: false }); break;
    }
    case 'decline-ai': pendingExternalText = null; $('#modal').close(); showFAQ('unknown'); break;
    case 'listen-modal': speak(modalClip); break;
    case 'route': showRoute(); break;
    case 'external': showExternal(button.dataset.url); break;
    case 'opened-external': $('#modal').close(); stopAudio(); break;
    case 'download': downloadChecklist(); break;
  }
});
document.addEventListener('change', event => {
  if (event.target.matches('[data-document]')) {
    const id = event.target.dataset.document;
    if (!DOCUMENTS.some(d => d.id === id)) return;
    state.ready = event.target.checked ? [...new Set([...state.ready, id])] : state.ready.filter(item => item !== id);
    const count = $('#stage .stage-eyebrow span:last-child'); if (count) count.textContent = `${state.ready.length} / ${DOCUMENTS.length}`;
  }
});
$('#language').addEventListener('change', event => setLanguage(event.target.value));
$('#question-form').addEventListener('submit', event => {
  event.preventDefault(); const input = $('#question-input'); const value = input.value.trim(); input.value = '';
  if (value) askQuestion(value, { allowAnswer: true });
});
$('#modal').addEventListener('click', event => { if (event.target === $('#modal')) { $('#modal').close(); stopAudio(); } });
$('#modal').addEventListener('cancel', () => { pendingExternalText = null; stopAudio(); });
function updateConnectivity() {
  const offline = !navigator.onLine; $('#offline-status').hidden = !offline; $('#offline-status').textContent = offline ? t('offlineNotice') : '';
}
window.addEventListener('offline', () => { updateConnectivity(); toast(t('offlineToast')); });
window.addEventListener('online', updateConnectivity);
window.addEventListener('pagehide', () => { cancelListening(); stopAudio(); });

hub = createHub({language:()=>lang,text:t,escape:esc,icon,isSpeaking:()=>speaking,cancel:cancelListening,stop:stopAudio,speak,toast,modal:modalShell,external:showExternal,redact:redactSensitive,query:askQuestion,mic:()=>startListening('question'),gas:()=>render({focus:true})});
$('.brand').addEventListener('click',event=>{event.preventDefault();hub.show('hub');});
localizePage(); if(hub.mode==='gas')render(); hub.render(); updateConnectivity();
fetch('/api/health', { signal: AbortSignal.timeout(4000) }).then(r => r.json()).then(data => { modelMode = data.mode === 'hybrid' ? 'hybrid' : 'local'; }).catch(() => {});
if ('serviceWorker' in navigator && window.isSecureContext) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
