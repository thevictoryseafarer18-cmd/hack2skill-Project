"""Optional app/web, image and install-contract QA. Native OS installation is not asserted."""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parent.parent
URL=os.environ.get('THOZHI_URL','http://127.0.0.1:3000')
checks=[];errors=[]
def check(name,value):
    assert value,name
    checks.append(name);print('PASS:',name,flush=True)
def action(p,name):return p.locator(f'[data-action="{name}"]').first
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=b.new_context(viewport={'width':1440,'height':1050});page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(URL);page.wait_for_selector('#stage-title');page.evaluate('document.fonts.ready')
    check('Desktop presents website layout with install control and task guide',page.locator('.desktop-install').is_visible() and page.locator('#app-nav').is_hidden())
    check('Desktop portrait asset decodes at full 3840×2160 resolution',page.locator('.hero-illustration').evaluate('(el)=>el.complete&&el.naturalWidth===3840&&el.naturalHeight===2160'))
    dims=page.evaluate('''async()=>{let i=new Image();i.src='/assets/images/clean-kitchen-4k.webp';await i.decode();return [i.naturalWidth,i.naturalHeight]}''')
    check('Kitchen background also decodes at 3840×2160',dims==[3840,2160])
    check('Kitchen scene is displayed behind readable website content',page.locator('.cooking-story').is_visible())
    action(page,'install').click();expect(page.locator('#modal')).to_be_visible()
    check('Install help explains Chrome and Safari, and clearly says web app rather than APK','Chrome' in page.locator('#modal').inner_text() and 'Safari' in page.locator('#modal').inner_text() and 'APK' in page.locator('#modal').inner_text())
    page.keyboard.press('Escape')
    # Emulate the install event contract. This is NOT actual native OS installation.
    page.evaluate('''() => {let e=new Event('beforeinstallprompt',{cancelable:true});window._prompted=0;e.prompt=async()=>{window._prompted++};e.userChoice=Promise.resolve({outcome:'accepted'});window.dispatchEvent(e)}''')
    action(page,'install').click();expect(action(page,'install-now')).to_be_visible();action(page,'install-now').click()
    check('Install-capable browser uses the browser prompt only after a user click',page.evaluate('window._prompted')==1)
    page.evaluate("window.dispatchEvent(new Event('appinstalled'))")
    check('Install-complete event clears duplicate install controls',page.locator('.desktop-install').is_hidden())
    # Reload resets transient install flags and the existing stateless journey.
    page.reload();page.wait_for_selector('#stage-title');page.set_viewport_size({'width':390,'height':844})
    check('Mobile switches to a fixed thumb-friendly app bar with four clear controls',page.locator('#app-nav').is_visible() and page.locator('#app-nav button').count()==4)
    page.wait_for_function('() => getComputedStyle(document.querySelector(".intro")).backgroundImage.includes("independent-woman-mobile.webp")')
    check('Mobile header uses the smaller 960×540 photographic rendition',page.locator('.intro').evaluate('(el)=>getComputedStyle(el).backgroundImage.includes("independent-woman-mobile.webp")'))
    page.locator('#app-nav [data-action="nav-languages"]').click();expect(page.locator('#modal')).to_be_visible()
    check('App language tab opens the complete eight-option language picker',page.locator('#modal [data-action="switch-language"]').count()==8)
    page.locator('#modal [data-action="switch-language"][data-lang="hi"]').click()
    check('App language picker applies Hindi and returns to the working guide',page.locator('#language').input_value()=='hi' and page.locator('#modal').is_hidden())
    page.locator('#app-nav [data-action="nav-help"]').click();expect(page.locator('#modal')).to_be_visible()
    check('App help tab shows localized instructions','पहली बार' in page.locator('#modal').inner_text())
    page.keyboard.press('Escape');action(page,'toggle-sound').click();action(page,'start').click()
    page.locator('[data-action="answer"][data-value="yes"]').click()
    page.locator('#app-nav [data-action="focus-guide"]').click()
    check('App guide tab preserves an in-progress answer rather than restarting','2 / 3' in page.locator('.stage-eyebrow').inner_text())
    page.locator('#app-nav [data-action="install"]').click()
    check('Install help never submits or resets the service journey','2 / 3' in page.locator('.stage-eyebrow').inner_text())
    page.keyboard.press('Escape');action(page,'restart').click();action(page,'confirm-restart').click()
    page.set_viewport_size({'width':360,'height':640})
    for lang in ['tl','ta','hi','te','kn','ml','bn','mr']:
        page.locator('#language').select_option(lang);page.evaluate('window.scrollTo(0,0)')
        entry=action(page,'start').bounding_box();nav=page.locator('#app-nav').bounding_box()
        check(f'{lang}: first start action remains above the fixed app bar on 360×640',entry['y']+entry['height']<=nav['y'])
    ctx.close()
    # All new CSS, translations and decorative photos remain available from cache.
    offline=b.new_context(viewport={'width':1440,'height':1000});q=offline.new_page();q.on('pageerror',lambda e:errors.append(str(e)))
    q.goto(URL);q.wait_for_function('() => navigator.serviceWorker.controller!==null');offline.set_offline(True);q.reload();q.wait_for_selector('#stage-title')
    check('Website imagery survives an offline reload after caching',q.locator('.hero-illustration').evaluate('(el)=>el.complete&&el.naturalWidth===3840'))
    check('New experience stylesheet is present offline','experience.css' in q.evaluate('Array.from(document.styleSheets).map(s=>s.href||"").join(" ")'))
    q.set_viewport_size({'width':390,'height':844});check('App navigation also survives offline',q.locator('#app-nav').is_visible())
    offline.close()
    # Standalone HTML is deliberately a demo, not an installable HTTPS origin.
    file=b.new_page(viewport={'width':390,'height':844});file.on('pageerror',lambda e:errors.append(str(e)))
    file.goto('file:///home/user/Thozhi-demo.html');file.wait_for_selector('#stage-title');file.locator('#app-nav [data-action="install"]').click()
    check('Standalone demo explains that installing requires the live web address','HTTPS' in file.locator('#modal').inner_text())
    file.keyboard.press('Escape');file.locator('#language').select_option('te');action(file,'toggle-sound').click();action(file,'start').click()
    for answer in ['yes','no','yes']:file.locator(f'[data-action="answer"][data-value="{answer}"]').click()
    check('Embedded-assets HTML still supports a native-language guided journey',file.locator('.result-note').is_visible())
    check('No uncaught JavaScript errors in app/web scenarios',not errors)
    b.close()
(ROOT/'docs/app-web-browser-checks.json').write_text(json.dumps({'checksPassed':len(checks),'checks':checks,'uncaughtErrors':errors,'nativeOSInstallationTested':False,'installPromptContractMocked':True,'realMicrophoneTested':False},ensure_ascii=False,indent=2)+'\n')
print(f'\n{len(checks)} app/web browser checks passed.')
