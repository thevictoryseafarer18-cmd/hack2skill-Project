"""Optional full-language browser QA. Requires Playwright; run app on port 3000.
ASR and regional TTS are contract-tested with mocks, not live provider claims.
"""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parent.parent
(ROOT.parent/'Thozhi-previews').mkdir(exist_ok=True)
URL=os.environ.get('THOZHI_URL','http://127.0.0.1:3000/?tool=gas')
raw=(ROOT/'public/lib/locales.js').read_text().split('export const UI_TRANSLATIONS =',1)[1].lstrip()
UI=json.JSONDecoder().raw_decode(raw)[0]
checks=[];errors=[]
def check(name, value):
    assert value, name
    checks.append(name);print('PASS:',name,flush=True)
def action(page,name):return page.locator(f'[data-action="{name}"]').first
def answer(page,value):page.locator(f'[data-action="answer"][data-value="{value}"]').click()
def ask(page,text):
    if page.locator('#question-form').is_hidden():action(page,'toggle-ask').click()
    page.locator('#question-input').fill(text);page.locator('#question-form').press('Enter')
def open_page(ctx):
    page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.goto(URL);page.wait_for_selector('#stage-title');return page
langs=['tl','ta','hi','te','kn','ml','bn','mr']
missing={'hi':'राशन कार्ड नहीं है','te':'రేషన్ కార్డు లేదు','kn':'ರೇಷನ್ ಕಾರ್ಡ್ ಇಲ್ಲ','ml':'റേഷൻ കാർഡ് ഇല്ല','bn':'রেশন কার্ড নেই','mr':'रेशन कार्ड नाही'}
script={'hi':'[\u0900-\u097F]','te':'[\u0C00-\u0C7F]','kn':'[\u0C80-\u0CFF]','ml':'[\u0D00-\u0D7F]','bn':'[\u0980-\u09FF]','mr':'[\u0900-\u097F]'}
with sync_playwright() as p:
    browser=p.chromium.launch(channel='chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':390,'height':844},accept_downloads=True)
    page=open_page(ctx);action(page,'toggle-sound').click()
    for lang in ['hi','te','kn','ml','bn','mr']:
        page.locator('#language').select_option(lang)
        check(f'{lang}: selected language sets the HTML locale',page.get_attribute('html','lang')==f'{lang}-IN')
        check(f'{lang}: welcome uses native text',page.locator('#stage-title').inner_text().startswith(UI[lang]['welcomeTitle']))
        action(page,'start').click();answer(page,'yes')
        ask(page,missing[lang]);expect(page.locator('#faq-answer')).to_be_visible()
        check(f'{lang}: native FAQ preserves the Annexure I migrant caveat','Annexure I' in page.locator('#faq-answer').inner_text())
        answer(page,'no');answer(page,'yes')
        check(f'{lang}: outcome includes a non-approval caveat',page.locator('.result-note').inner_text()==UI[lang]['possibleNote'])
        action(page,'documents').click()
        check(f'{lang}: all five native document choices are present',page.locator('[data-document]').count()==5 and 'undefined' not in page.locator('#stage').inner_text())
        page.locator('#doc-bank').check();action(page,'next').click()
        with page.expect_download() as event:action(page,'download').click()
        plan=Path(event.value.path()).read_text(encoding='utf-8-sig')
        import re
        check(f'{lang}: downloaded checklist is localized',bool(re.search(script[lang],plan)) and 'No application has been submitted' not in plan and 'undefined' not in plan)
        action(page,'route').click();check(f'{lang}: native in-person instructions and official links work','PMUY' in page.locator('#modal').inner_text() and page.locator('#modal .source-card').count()==2)
        page.keyboard.press('Escape');action(page,'restart').click();action(page,'confirm-restart').click()
    # Changing the language never deletes previous user choices.
    action(page,'start').click();answer(page,'yes');page.locator('#language').select_option('te')
    check('Changing languages preserves the current question and prior answers',page.locator('.stage-eyebrow').inner_text().startswith('ప్రశ్న 2'))
    answer(page,'no');answer(page,'yes');action(page,'documents').click();page.locator('#doc-bank').check();page.locator('#language').select_option('bn')
    check('Changing languages preserves document checkmarks',page.locator('#doc-bank').is_checked())
    ctx.close()
    # Screen widths: the page must never push sideways in any of the eight options.
    responsive=browser.new_context(viewport={'width':390,'height':844});r=open_page(responsive)
    for width in [320,360,390,768,1024,1440]:
        r.set_viewport_size({'width':width,'height':844})
        for lang in langs:
            r.locator('#language').select_option(lang)
            check(f'{lang}: no horizontal overflow at {width}px',r.evaluate('document.documentElement.scrollWidth<=innerWidth'))
    r.set_viewport_size({'width':360,'height':640})
    for lang in langs:
        r.locator('#language').select_option(lang)
        entry=action(r,'start').bounding_box()
        check(f'{lang}: tap-to-start fits on a short 360×640 phone',entry['y']+entry['height']<=640)
    r.set_viewport_size({'width':390,'height':844});r.locator('#language').select_option('te');r.evaluate('document.fonts.ready')
    r.screenshot(path=str(ROOT.parent/'Thozhi-previews/telugu-mobile-preview.jpg'),full_page=True,type='jpeg',quality=90,animations='disabled')
    r.set_viewport_size({'width':1440,'height':1000});r.locator('#language').select_option('hi');r.evaluate('document.fonts.ready')
    r.screenshot(path=str(ROOT.parent/'Thozhi-previews/hindi-preview.jpg'),full_page=True,type='jpeg',quality=90,animations='disabled')
    r.locator('[data-action="switch-language"][data-lang="ml"]').first.click()
    check('Colourful language tiles are functional, not decoration',r.locator('#language').input_value()=='ml')
    responsive.close()
    # Mock only the browser voice APIs so the requested BCP-47 locale is observable.
    voice=browser.new_context(viewport={'width':390,'height':844})
    voice.add_init_script('''window._spoken=[];window._recognition=[];
      const locales=['hi-IN','te-IN','kn-IN','ml-IN','bn-IN','mr-IN'];
      Object.defineProperty(window,'speechSynthesis',{value:{getVoices:()=>locales.map(lang=>({lang,name:'Test voice',localService:true})),speak:u=>{window._spoken.push({lang:u.lang,text:u.text});setTimeout(()=>u.onend?.(),50)},cancel:()=>{},addEventListener:()=>{},removeEventListener:()=>{}}});
      window.SpeechSynthesisUtterance=class{constructor(text){this.text=text}};
      const answers={'hi-IN':'हाँ','te-IN':'అవును','kn-IN':'ಹೌದು','ml-IN':'അതെ','bn-IN':'হ্যাঁ','mr-IN':'होय'};
      window.SpeechRecognition=window.webkitSpeechRecognition=class{
        start(){window._recognition.push(this.lang);this.onstart?.();this.timer=setTimeout(()=>{if(this._cancelled)return;this.onresult?.({results:[[{transcript:answers[this.lang]}]]});this.onend?.()},100)}
        stop(){clearTimeout(this.timer);this.onend?.()}abort(){clearTimeout(this.timer);this.onend?.()}
      };
    ''')
    v=open_page(voice)
    audio_requests=[];v.on('request',lambda req:audio_requests.append(req.url) if '/assets/audio/' in req.url else None)
    for lang in ['hi','te','kn','ml','bn','mr']:
        v.locator('#language').select_option(lang);action(v,'listen').click()
        v.wait_for_function('() => window._spoken.length>0')
        check(f'{lang}: TTS uses the chosen locale, not Tamil or English',v.evaluate('window._spoken.at(-1).lang')==f'{lang}-IN' and v.evaluate('window._spoken.at(-1).text').startswith(UI[lang]['welcomeTitle']))
        action(v,'start').click();action(v,'mic').click();expect(v.locator('[data-action="confirm-answer"]')).to_be_visible()
        check(f'{lang}: recognition uses the chosen locale and waits for confirmation',v.evaluate('window._recognition.at(-1)')==f'{lang}-IN' and v.locator('.stage-eyebrow').inner_text().endswith('PMUY'))
        action(v,'confirm-answer').click();check(f'{lang}: confirmed native yes advances exactly once','2 / 3' in v.locator('.stage-eyebrow').inner_text())
        action(v,'restart').click();action(v,'confirm-restart').click()
        v.evaluate('window._spoken=[]')
    check('New languages never play a bundled Tamil recording',not audio_requests)
    voice.close()
    # Missing regional phone voices cause an honest message, never wrong-language speech.
    absent=browser.new_context()
    absent.add_init_script('''Object.defineProperty(window,'speechSynthesis',{value:{getVoices:()=>[],cancel:()=>{},addEventListener:()=>{},removeEventListener:()=>{},speak:()=>{throw Error('No voice should be called')}}});''')
    a=open_page(absent);a.locator('#language').select_option('hi');action(a,'listen').click()
    expect(a.locator('#toast')).to_be_visible()
    check('Unavailable Hindi voice is explained in Hindi while buttons remain usable','हिन्दी' in a.locator('#toast').inner_text() and action(a,'start').is_enabled())
    absent.close()
    # Cached translations and local fonts work after an offline reload.
    offline_ctx=browser.new_context(viewport={'width':390,'height':844});off=open_page(offline_ctx)
    off.wait_for_function('() => navigator.serviceWorker.controller!==null')
    offline_ctx.set_offline(True);off.reload();off.wait_for_selector('#stage-title');action(off,'toggle-sound').click()
    for lang in ['hi','te','kn','ml','bn','mr']:
        off.locator('#language').select_option(lang);action(off,'start').click()
        for val in ['yes','no','yes']:answer(off,val)
        action(off,'documents').click();check(f'{lang}: full native journey works offline',off.locator('[data-document]').count()==5)
        action(off,'restart').click();action(off,'confirm-restart').click()
    offline_ctx.close()
    check('No uncaught errors across multilingual scenarios',not errors)
    browser.close()
(ROOT/'docs/multilingual-browser-checks.json').write_text(json.dumps({'checksPassed':len(checks),'checks':checks,'uncaughtErrors':errors,'regionalSpeechAPIsMocked':True,'realMicrophoneTested':False,'liveGeminiTested':False},ensure_ascii=False,indent=2)+'\n')
print(f'\n{len(checks)} multilingual browser checks passed.')
