// Export a genuinely standalone demo: no CDN, imports, model download, or server.
// The full server project remains the GitHub submission; export stays outside it.
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(fileURLToPath(new URL('../', import.meta.url)));
const read = name => readFile(path.join(root, 'public', name), 'utf8');
const mime = { '.svg': 'image/svg+xml', '.png': 'image/png', '.webp': 'image/webp', '.woff2': 'font/woff2', '.mp3': 'audio/mpeg' };
async function data(name) {
  const buffer = await readFile(path.join(root, 'public', name));
  return `data:${mime[path.extname(name)]};base64,${buffer.toString('base64')}`;
}
let html = await read('index.html');
let css = (await read('style.css')) + '\n' + (await read('experience.css')) + '\n' + (await read('hub.css'));
html = html.replace('<link rel="stylesheet" href="/hub.css">', '');
html = html.replace('<link rel="stylesheet" href="/experience.css">', '');
for (const font of ['dm-sans', 'noto-tamil', 'noto-devanagari', 'noto-telugu', 'noto-kannada', 'noto-malayalam', 'noto-bengali']) css = css.replaceAll(`/assets/fonts/${font}.woff2`, await data(`assets/fonts/${font}.woff2`));
for (const image of ['logo.svg', 'companion.svg', 'icon-192.png']) html = html.replaceAll(`/assets/${image}`, await data(`assets/${image}`));
for (const photo of ['independent-woman-4k.webp', 'clean-kitchen-4k.webp', 'independent-woman-mobile.webp']) {
  const uri = await data(`assets/images/${photo}`);
  css = css.replaceAll(`/assets/images/${photo}`, uri);
  html = html.replaceAll(`/assets/images/${photo}`, uri);
}
html = html.replace(/\s*<link rel="manifest"[^>]*>/, '').replace('<link rel="stylesheet" href="/style.css">', `<style>${css}</style>`);
html = html.replace('class="brand" href="/"', 'class="brand" href="#guide"');
let scheme = (await read('lib/scheme.js')).replace(/^export /gm, '').replace(/^import .*;\n/gm, '');
let schemeTranslations = (await read('lib/scheme-translations.js')).replace(/^export /gm, '');
let experienceUI = (await read('lib/experience-ui.js')).replace(/^export /gm, '');
let locales = (await read('lib/locales.js')).replace(/^export /gm, '').replace(/^import .*;\n/gm, '');
let indicIntents = (await read('lib/indic-intents.js')).replace(/^export /gm, '');
let model = (await read('lib/intent-model.js')).replace(/^export /gm, '').replace(/^import .*;\n/gm, '');
let app = (await read('app.js')).replace(/^import .*;\n/gm, '');
const clips = ['hub-welcome','learn-welcome','welcome','adult','lpg','poor','documents','next','help','possible','review','confirm'];
const audio = Object.fromEntries(await Promise.all(clips.map(async name => [name, await data(`assets/audio/${name}.mp3`)])));
app = app.replace('audio.src = `/assets/audio/${clip}.mp3`;', 'audio.src = AUDIO_ASSETS[clip];');
app = app.replaceAll('/assets/logo.svg', await data('assets/logo.svg'));
app = app.replace(/^fetch\('\/api\/health'.*$/gm, '// Standalone demo: intentionally local AI only.');
app = app.replace(/^if \('serviceWorker' in navigator.*$/gm, '// All public assets are already embedded; no service worker needed.');
const hubModules = await Promise.all(['hub-ui','hub-services','learning-data','states','hub-router','hub'].map(async name => (await read(`lib/${name}.js`)).replace(/^export /gm,'').replace(/^import .*;\n/gm,'')));
const script = `const AUDIO_ASSETS = ${JSON.stringify(audio)};\n${schemeTranslations}\n${experienceUI}\n${locales}\n${indicIntents}\n${scheme}\n${model}\n${hubModules.join("\n")}\n${app}`.replace(/<\/script/gi, '<\\/script');
html = html.replace('<script type="module" src="/app.js"></script>', '')
  // Function replacer preserves JavaScript's literal $`, $&, and $' sequences.
  .replace('</body>', () => `<script type="module">${script}</script>\n</body>`);
html = html.replace('<!doctype html>', '<!doctype html>\n<!-- Thozhi standalone demonstration. MIT code; bundled fonts SIL OFL. No application is submitted. -->');
// Include the full font attribution/license in a non-rendered HTML comment.
for (const file of ['dmsans-OFL.txt', 'notosanstamil-OFL.txt', ...['devanagari','telugu','kannada','malayalam','bengali'].map(script => `noto-${script}-OFL.txt`)]) {
  const license = await read(`assets/fonts/${file}`);
  html = html.replace('</html>', `<!-- ${license.replaceAll('--', '—')} -->\n</html>`);
}
const projectLicense = await readFile(path.join(root, 'LICENSE'), 'utf8');
html = html.replace('</html>', () => `<!-- ${projectLicense.replaceAll('--', '—')} -->\n</html>`);
const destination = path.resolve(process.argv[2] || path.join(root, '..', 'Thozhi-demo.html'));
await writeFile(destination, html);
console.log(`Standalone demo saved: ${destination} (${(Buffer.byteLength(html) / 1000000).toFixed(2)} MB)`);
