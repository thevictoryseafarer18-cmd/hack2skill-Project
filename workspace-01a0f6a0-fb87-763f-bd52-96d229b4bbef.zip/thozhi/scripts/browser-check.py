"""Optional browser QA. Requires Python Playwright + its Chromium installation.
Run the app first, then: python scripts/browser-check.py
Actual speech service accuracy and microphone hardware are NOT simulated claims.
"""
import json, os
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent.parent
(ROOT.parent/'Thozhi-previews').mkdir(exist_ok=True)
URL = os.environ.get('THOZHI_URL', 'http://127.0.0.1:3000/?tool=gas')
checks = []
errors = []
def check(name, passed):
    assert passed, name
    checks.append(name)
    print('PASS:', name, flush=True)
def action(page, name):
    return page.locator(f'[data-action="{name}"]').first
def answer(page, value):
    page.locator(f'[data-action="answer"][data-value="{value}"]').click()
def start(page):
    action(page, 'start').click()
def ask(page, text):
    if page.locator('#question-form').is_hidden(): action(page, 'toggle-ask').click()
    page.locator('#question-input').fill(text)
    page.locator('#question-form').press('Enter')
def finish(page, values=('yes', 'no', 'yes')):
    start(page)
    for value in values: answer(page, value)
def open_page(context):
    page = context.new_page()
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.goto(URL)
    page.wait_for_selector('#stage-title')
    return page

with sync_playwright() as p:
    browser = p.chromium.launch(channel='chromium', headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
    context = browser.new_context(viewport={'width':1440, 'height':1000}, accept_downloads=True)
    page = open_page(context)
    page.evaluate('document.fonts.ready')
    page.screenshot(path=str(ROOT.parent/'Thozhi-previews/preview.jpg'), full_page=True, type='jpeg', quality=90, animations='disabled')
    check('Tanglish default with working local scripts', 'Vanakkam' in page.locator('#stage-title').inner_text())
    action(page, 'listen').click()
    expect(page.locator('.guide-toolbar .listen-button')).to_have_class('listen-button speaking')
    check('Tamil welcome audio starts in a real browser', True)
    action(page, 'listen').click()
    durations = page.evaluate('''async () => {
      const clips = ['welcome','adult','lpg','poor','documents','next','help','possible','review','confirm'];
      return await Promise.all(clips.map(name => new Promise((resolve,reject) => {
        const a = new Audio('/assets/audio/' + name + '.mp3');
        a.onloadedmetadata = () => resolve({name, duration:a.duration});
        a.onerror = reject; a.load();
      })));
    }''')
    check('All ten bundled MP3s decode with nonzero durations', len(durations)==10 and all(d['duration']>0 for d in durations))
    action(page, 'toggle-sound').click()
    action(page, 'how').click()
    expect(page.locator('#modal')).to_be_visible()
    check('Help explains local intent AI honestly', 'On-device intent AI' in page.locator('#modal').inner_text())
    page.keyboard.press('Escape')
    expect(page.locator('#modal')).not_to_be_visible()
    check('Modal keyboard escape works', True)
    start(page)
    ask(page, 'adutha padi')
    check('A continue command cannot skip an unanswered eligibility question', '18 vayasu' in page.locator('#stage-title').inner_text())
    ask(page, 'aama')
    expect(page.locator('#voice-feedback')).to_be_visible()
    check('Interpreted answer does not auto-advance', '18 vayasu' in page.locator('#stage-title').inner_text())
    action(page, 'reject-answer').click()
    check('Rejecting an interpretation keeps the current question', '18 vayasu' in page.locator('#stage-title').inner_text())
    ask(page, 'aama')
    action(page, 'confirm-answer').click()
    check('Confirmed answer moves exactly one question', 'yaar peyarilaavadhu' in page.locator('#stage-title').inner_text())
    answer(page, 'no'); answer(page, 'yes')
    check('Potential outcome is not government approval', 'final approval illa' in page.locator('#stage').inner_text())
    ask(page, 'adutha padi')
    check('Continue intent moves outcome to the document step', 'Enna kondu poganum' in page.locator('#stage-title').inner_text())
    page.locator('#doc-family').check(); page.locator('#doc-bank').check()
    page.locator('.document-item details').first.locator('summary').click()
    check('Document explanations expand', 'vayadhu vandha' in page.locator('.document-item details').first.inner_text())
    ask(page, 'ration card illa')
    check('Local AI answers missing ration card with migrant caveat', 'Annexure I' in page.locator('#faq-answer').inner_text())
    ask(page, 'adutha padi')
    check('Continue intent moves documents to the final step', 'Ippo neenga seiyalaam' in page.locator('#stage-title').inner_text())
    check('Next step explicitly says not submitted', 'Vinnappam innum anuppappadavillai' in page.locator('#stage').inner_text())
    with page.expect_download() as event: action(page, 'download').click()
    plan = Path(event.value.path()).read_text(encoding='utf-8-sig')
    check('Downloaded plan reflects selected documents and no approval', '[✓] Ration' in plan and 'No application has been submitted' in plan)
    action(page, 'route').click()
    check('In-person route has a usable phrase and official distributor links', 'Enakku Ujjwala / PMUY' in page.locator('#modal').inner_text() and page.locator('#modal .source-card').count()==2)
    action(page, 'close-modal').click()
    action(page, 'external').click()
    check('Official handoff requires explicit confirmation', page.locator('#modal a[target="_blank"]').get_attribute('href')=='https://www.pmuy.gov.in/ujjwala2.html')
    action(page, 'close-modal').click()
    action(page, 'back').click()
    check('Back preserves document selections', page.locator('#doc-family').is_checked() and page.locator('#doc-bank').is_checked())
    page.locator('#language').select_option('ta')
    check('Tamil script mode changes the working journey', 'ஆவண' in page.locator('#stage').inner_text())
    page.locator('#language').select_option('tl')
    action(page, 'restart').click(); action(page, 'confirm-restart').click()
    finish(page, ('no', 'no', 'yes'))
    check('Under-age case is not marked potentially eligible', 'Sila conditions porundhavillai' in page.locator('#stage-title').inner_text())
    action(page, 'restart').click(); action(page, 'confirm-restart').click()
    finish(page, ('yes', 'yes', 'yes'))
    check('Existing household LPG is not marked potentially eligible', 'already gas connection' in page.locator('#stage').inner_text())
    action(page, 'restart').click(); action(page, 'confirm-restart').click()
    finish(page, ('unsure', 'no', 'yes'))
    check("Don't know gets a confirmation route", 'Parava illa' in page.locator('#stage-title').inner_text())
    ask(page, 'write me a chocolate cake recipe')
    check('Unrelated question gets no invented scheme answer', 'Indha kelvi sariyaa puriyala' in page.locator('#faq-answer').inner_text())
    ask(page, 'aadhaar 123456789012 sollanuma')
    check('Typed identifier is redacted and not visible', '123456789012' not in page.locator('body').inner_text())
    check('Answers never enter browser local/session storage', page.evaluate('localStorage.length===0 && sessionStorage.length===0'))
    context.close()

    # The frontend consent flow is tested with mocked API replies, not Gemini.
    consent_context = browser.new_context(viewport={'width':390,'height':844})
    outbound = []
    consent_context.route('**/api/health', lambda route: route.fulfill(json={'ok':True,'mode':'hybrid'}))
    def fake_assist(route):
        outbound.append(route.request.post_data_json)
        route.fulfill(json={'intent':'apply','mode':'hybrid','confidence':None})
    consent_context.route('**/api/assist', fake_assist)
    consent = open_page(consent_context)
    consent.wait_for_load_state('networkidle')
    action(consent,'toggle-sound').click()
    ask(consent,'kurippitta sirappu padi')
    expect(consent.locator('#modal')).to_be_visible()
    check('Optional external AI asks for consent before any query is sent', not outbound and 'Gemini' in consent.locator('#modal').inner_text())
    action(consent,'decline-ai').click()
    check('Declining external AI keeps a safe local response', not outbound and 'Indha kelvi sariyaa puriyala' in consent.locator('#faq-answer').inner_text())
    ask(consent,'kurippitta sirappu padi 123456789012')
    action(consent,'accept-ai').click()
    expect(consent.locator('#faq-answer h4')).to_have_text('Eppadi vinnappikkanum?')
    check('Consented external request carries only redacted text and permission flag', len(outbound)==1 and outbound[0].get('allowExternal')==True and '123456789012' not in outbound[0]['text'])
    check('External intent still displays curated application disclaimer', 'Thozhi inge vinnappathai anuppaadhu' in consent.locator('#faq-answer').inner_text())
    consent_context.close()

    # Real recognition is not used here: this exercises the recognition callbacks.
    voice_context = browser.new_context(viewport={'width':390, 'height':844})
    voice_context.add_init_script('''window.SpeechRecognition = window.webkitSpeechRecognition = class {
      start(){ this.onstart?.(); this.timer=setTimeout(()=>{if(this._cancelled)return; this.onresult?.({results:[[{transcript:'இல்லை'}]]}); this.onend?.();},150); }
      stop(){clearTimeout(this.timer);this.onend?.();}
      abort(){clearTimeout(this.timer);this.onend?.();}
    };''')
    voice_page = open_page(voice_context)
    action(voice_page, 'toggle-sound').click(); start(voice_page); action(voice_page, 'mic').click()
    expect(voice_page.locator('[data-action="confirm-answer"]')).to_be_visible()
    check('Mocked Tamil recognition still requires confirmation', '18 vayasu' in voice_page.locator('#stage-title').inner_text())
    action(voice_page, 'confirm-answer').click()
    check('Confirmed Tamil no advances safely', 'yaar peyarilaavadhu' in voice_page.locator('#stage-title').inner_text())
    voice_context.close()

    fallback_context = browser.new_context(viewport={'width':360, 'height':640})
    fallback_context.add_init_script('window.SpeechRecognition=undefined; window.webkitSpeechRecognition=undefined;')
    fallback = open_page(fallback_context)
    action(fallback, 'toggle-sound').click(); action(fallback, 'mic').click()
    check('Unsupported speech browser offers the same tappable journey', 'periya badhil button' in fallback.locator('#voice-feedback').inner_text() and action(fallback,'start').is_enabled())
    start(fallback); answer(fallback,'yes')
    check('Fallback route advances without voice', 'yaar peyarilaavadhu' in fallback.locator('#stage-title').inner_text())
    fallback_context.close()

    # PWA: after first cache installation, local modules and all public audio work.
    offline_context = browser.new_context(viewport={'width':390,'height':844})
    offline = open_page(offline_context)
    offline.wait_for_function('() => navigator.serviceWorker.controller !== null')
    cache_urls = offline.evaluate('''async () => {let name=(await caches.keys()).find(n=>n.startsWith('thozhi-')); let c=await caches.open(name); return (await c.keys()).map(r=>r.url);}''')
    check('Only public assets are cached, including ten audio files', sum('/audio/' in u for u in cache_urls)==10 and not any('/api/' in u for u in cache_urls))
    offline_context.set_offline(True)
    offline.reload(); offline.wait_for_selector('#stage-title')
    action(offline,'toggle-sound').click(); finish(offline)
    check('Entire eligibility journey works after an offline reload', 'Adutha padi pogalaam' in offline.locator('#stage-title').inner_text())
    ask(offline,'enna documents venum')
    check('Intent AI and approved FAQ work offline', 'Enna aavanangal thevai' in offline.locator('#faq-answer').inner_text())
    offline_context.close()

    responsive_context = browser.new_context()
    responsive = open_page(responsive_context)
    for width in [320,360,390,768,1024,1440]:
        responsive.set_viewport_size({'width':width,'height':844})
        for language in ['tl','ta']:
            responsive.locator('#language').select_option(language)
            check(f'No horizontal overflow at {width}px in {language}', responsive.evaluate('document.documentElement.scrollWidth <= innerWidth'))
    responsive.set_viewport_size({'width':390,'height':844});responsive.locator('#language').select_option('tl');responsive.evaluate('document.fonts.ready')
    responsive.screenshot(path=str(ROOT.parent/'Thozhi-previews/mobile-preview.jpg'), full_page=True, type='jpeg', quality=90, animations='disabled')
    responsive.set_viewport_size({'width':360,'height':640})
    mic = action(responsive,'mic').bounding_box()
    check('Primary voice start is visible on a 360×640 phone', mic['y']+mic['height'] <= 640)
    responsive_context.close()
    check('No uncaught browser JavaScript errors', not errors)
    browser.close()

(ROOT/'docs/browser-checks.json').write_text(json.dumps({'checksPassed':len(checks),'checks':checks,'uncaughtErrors':errors,'audioDurations':durations,'realMicrophoneTested':False,'liveGeminiTested':False},indent=2,ensure_ascii=False)+'\n')
print(f'\n{len(checks)} browser checks passed.')
