"""Optional India-wide service/learning browser QA. Official applications remain external."""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parent.parent
URL=os.environ.get('THOZHI_HUB_URL','http://127.0.0.1:3000')
checks=[];errors=[]
def check(name,value):
 assert value,name
 checks.append(name);print('PASS:',name,flush=True)
def ha(p,name):return p.locator(f'[data-hub-action="{name}"]').first
def action(p,name):return p.locator(f'[data-action="{name}"]').first
def home(p):p.locator('.brand').click()
def query(p,text):
 p.locator('#hub-question').fill(text);p.locator('#hub-question-form').press('Enter')
def open_page(ctx):
 p=ctx.new_page();p.on('pageerror',lambda e:errors.append(str(e)));p.goto(URL);p.wait_for_selector('.hub-start-card');return p
with sync_playwright() as p:
 b=p.chromium.launch(channel='chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 ctx=b.new_context(viewport={'width':1440,'height':1050},accept_downloads=True);page=open_page(ctx)
 check('Default homepage is India-wide, not gas-only',page.locator('.hub-service-card').count()==17 and page.locator('#legacy-page').is_hidden())
 page.locator('[data-hub-action="listen"]').first.click();expect(page.locator('[data-hub-action="listen"]').first).to_have_class('listen-button speaking')
 check('New bundled Tamil hub welcome starts actual browser playback',page.locator('[data-hub-action="listen"]').first.get_attribute('aria-pressed')=='true')
 page.locator('[data-hub-action="listen"]').first.click()
 check('Hub narration can be explicitly stopped',page.locator('[data-hub-action="listen"]').first.get_attribute('aria-pressed')=='false')
 page.locator('#hub-service-search').fill('ration card');expect(page.locator('.hub-service-card')).to_have_count(1)
 check('Service search recognizes a natural service name',page.locator('.hub-service-card').get_attribute('data-service')=='ration')
 page.locator('#hub-service-search').fill('')
 for service in ['aadhaar','ration','health','doctor','pension','work','eshram','bank','shg','scholarship','skills','digilocker','directory','maternity','housing','farmer']:
  page.locator(f'[data-hub-action="service"][data-service="{service}"]').click()
  check(f'{service}: source-linked guide has five steps, preparation and a real offline channel',page.locator('.hub-steps li').count()==5 and page.locator('.hub-offline-route').is_visible() and page.locator('.hub-source-link').count()>=1)
  check(f'{service}: no real identity, password or bank input collection',page.locator('.hub-detail input').count()==0)
  if service=='ration':
   with page.expect_download() as ev:ha(page,'save-plan').click()
   plan=Path(ev.value.path()).read_text(encoding='utf-8-sig')
   check('Service plan downloads real official URL and no-submission caveat','https://nfsa.gov.in/portal/apply_ration_card' in plan and 'No application has been submitted' in plan)
   page.locator('.hub-source-link').first.click();expect(page.locator('#modal')).to_be_visible()
   check('Service handoff displays official domain and requires explicit external opening','nfsa.gov.in' in page.locator('#modal').inner_text() and page.locator('#modal a[target="_blank"]').count()==1)
   page.keyboard.press('Escape')
  ha(page,'view').click()
 check('36 state and UT directories are available',page.locator('#hub-state option').count()==37)
 page.locator('#hub-state').select_option('TN');ha(page,'state').click()
 check('State route uses audited iGOD code, not a guessed application URL',page.locator('#modal a[target="_blank"]').get_attribute('href')=='https://igod.gov.in/sg/TN/categories')
 page.keyboard.press('Escape')
 query(page,'aadhaar address maathanum');expect(page.locator('.hub-detail')).to_be_visible()
 check('Local AI routes government questions beyond LPG',page.locator('#hub-title').inner_text()=='Aadhaar udhavi')
 home(page);query(page,'make chocolate cheesecake')
 check('Unsupported request stays a safe unknown rather than invented government advice',page.locator('#hub-feedback').is_visible() and page.locator('.hub-service-card').count()==17)
 query(page,'internet kathukkanum');expect(page.locator('.hub-lesson-card')).to_have_count(6)
 check('Local AI opens the Internet learning section',page.locator('.hub-resource-grid button').count()==8)
 ha(page,'listen').click();expect(ha(page,'listen')).to_have_class('listen-button speaking')
 check('New Tamil learning welcome also plays in the browser',ha(page,'listen').get_attribute('aria-pressed')=='true');ha(page,'listen').click()
 for lesson in ['phone','web','forms','documents','safety','payments']:
  page.locator(f'[data-hub-action="lesson"][data-lesson="{lesson}"]').click()
  check(f'{lesson}: localized original lesson has three concrete steps and linked sources',page.locator('.hub-steps li').count()==3 and page.locator('.hub-source-link').count()>=1)
  if lesson=='phone':
   ha(page,'practice').click();ha(page,'practice-next').click();ha(page,'practice-success').click()
   check('Tap and Back practice completes without a real transaction','Super!' in page.locator('#modal').inner_text());page.keyboard.press('Escape')
  if lesson=='forms':
   ha(page,'practice').click();page.locator('#practice-input').fill('123456789012');page.locator('#hub-practice-form').press('Enter')
   check('Practice never echoes or retains an attempted real identifier','123456789012' not in page.locator('#modal').inner_text() and page.locator('#practice-input').input_value()=='')
   page.locator('#practice-input').fill('Thozhi');page.locator('#hub-practice-form').press('Enter')
   check('Sample form practice checks only the provided harmless word','Super!' in page.locator('#practice-feedback').inner_text());page.keyboard.press('Escape')
  if lesson=='safety':
   ha(page,'practice').click();ha(page,'scam-unsafe').click();check('Unsafe OTP practice choice teaches refusal',page.locator('#practice-feedback').is_visible())
   ha(page,'scam-safe').click();check('Safe OTP practice distinguishes caller sharing from legitimate initiated OTP use','official' in page.locator('#practice-feedback').inner_text());page.keyboard.press('Escape')
  if lesson=='payments':check('Payments lesson never makes a payment or asks for a PIN',page.locator('.hub-detail input').count()==0 and '1930' in page.locator('.hub-detail').inner_text())
  ha(page,'complete-lesson').click()
 check('Lesson progress is session-only and not a certificate','6 / 6' in page.locator('.hub-learning-hero .eyebrow').inner_text())
 with page.expect_download() as ev:ha(page,'save-study').click()
 notes=Path(ev.value.path()).read_text(encoding='utf-8-sig')
 check('Downloadable study notes contain all topics plus trusted PDF/course URLs','UPI' in notes and 'https://www.cert-in.org.in/PDF/Mahila_Suraksha_Booklet25.pdf' in notes and 'https://diksha.gov.in/' in notes)
 home(page);page.locator('[data-service="gas"]').click();expect(page.locator('#stage-title')).to_be_visible()
 action(page,'toggle-sound').click();action(page,'start').click();page.locator('[data-action="answer"][data-value="yes"]').click();home(page);page.locator('[data-service="gas"]').click()
 check('Original Ujjwala guide remains and retains an answer when returning from hub','2 / 3' in page.locator('.stage-eyebrow').inner_text())
 home(page)
 check('No answers or learning history enter browser storage',page.evaluate('localStorage.length===0&&sessionStorage.length===0'))
 # Real script switching, service guides and notes in every text option.
 page.set_viewport_size({'width':390,'height':844})
 for lang in ['tl','ta','hi','te','kn','ml','bn','mr']:
  page.locator('#language').select_option(lang);home(page)
  check(f'{lang}: hub content localizes without undefined fields','undefined' not in page.locator('#hub-page').inner_text())
  page.locator('[data-service="ration"]').click();check(f'{lang}: translated service guide and state names are available',page.locator('.hub-steps li').count()==5 and page.locator('#hub-state option').count()==37)
  home(page);page.locator('#app-nav [data-view="learn"]').click();page.locator('[data-lesson="forms"]').click();ha(page,'practice').click()
  sample=page.locator('.sample-word').inner_text();page.locator('#practice-input').fill(sample);page.locator('#hub-practice-form').press('Enter')
  check(f'{lang}: native-word form practice works',page.locator('#practice-feedback').is_visible());page.keyboard.press('Escape');home(page)
 for width in [320,360,390,768,1024,1440]:
  page.set_viewport_size({'width':width,'height':844})
  for lang in ['tl','ta','hi','te','kn','ml','bn','mr']:
   page.locator('#language').select_option(lang)
   check(f'{lang}: no sideways overflow at {width}px',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 page.set_viewport_size({'width':360,'height':640})
 for lang in ['tl','ta','hi','te','kn','ml','bn','mr']:
  page.locator('#language').select_option(lang);page.evaluate('window.scrollTo(0,0)')
  button=page.locator('.hub-start-card [data-view="learn"]').bounding_box();nav=page.locator('#app-nav').bounding_box()
  check(f'{lang}: both first choices remain above the app bar on a short phone',button['y']+button['height']<=nav['y'])
 ctx.close()
 offctx=b.new_context(viewport={'width':390,'height':844});off=open_page(offctx);off.wait_for_function('() => navigator.serviceWorker.controller!==null');offctx.set_offline(True);off.reload();off.wait_for_selector('.hub-start-card')
 check('India-wide hub reloads offline after caching',off.locator('.hub-service-card').count()==17)
 off.locator('[data-service="ration"]').click();off.locator('.hub-source-link').first.click()
 check('Offline official handoff offers saved notes, not fake submission',off.locator('#modal a[target="_blank"]').count()==0);off.keyboard.press('Escape');home(off)
 off.locator('#app-nav [data-view="learn"]').click();off.locator('[data-lesson="safety"]').click();ha(off,'practice').click();ha(off,'scam-safe').click()
 check('Learning and scam practice work without internet',off.locator('#practice-feedback').is_visible())
 offctx.close();check('No uncaught JavaScript errors in hub scenarios',not errors);b.close()
(ROOT/'docs/hub-browser-checks.json').write_text(json.dumps({'checksPassed':len(checks),'checks':checks,'uncaughtErrors':errors,'officialApplicationsSubmitted':False,'externalGovernmentFormsTested':False,'realMicrophoneTested':False},ensure_ascii=False,indent=2)+'\n')
print(f'\n{len(checks)} hub/browser checks passed.')
