// Conservative preflight: payload + local .git together must be < 10,000,000 bytes.
// --remote additionally checks public visibility and branch count through GitHub.
import { readdir, stat } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(fileURLToPath(new URL('../', import.meta.url)));
const ignored = new Set(['node_modules', '.cache', 'coverage', 'test-results', 'playwright-report']);
let failed = false;
async function size(directory, skipGit = false) {
  let bytes = 0;
  for (const file of await readdir(directory, { withFileTypes: true })) {
    if (ignored.has(file.name) || (skipGit && file.name === '.git') || file.isSymbolicLink()) continue;
    const full = path.join(directory, file.name);
    bytes += file.isDirectory() ? await size(full, skipGit) : (await stat(full)).size;
  }
  return bytes;
}
const payload = await size(ROOT, true);
let gitBytes = 0;
try { gitBytes = await size(path.join(ROOT, '.git')); } catch {}
console.log(`Source + assets: ${(payload / 1000000).toFixed(2)} MB`);
console.log(`Local Git history: ${(gitBytes / 1000000).toFixed(2)} MB`);
console.log(`Conservative combined size: ${((payload + gitBytes) / 1000000).toFixed(2)} MB`);
if (payload + gitBytes >= 10000000) { failed = true; console.error('FAIL: conservative repository size is not less than 10 MB.'); }
else console.log('PASS: below the 10 MB limit.');
const git = args => execFileSync('git', args, { cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
try {
  const branches = git(['for-each-ref', '--format=%(refname:short)', 'refs/heads']).split('\n').filter(Boolean);
  console.log(`Local branches: ${branches.join(', ') || '(none)'}`);
  if (branches.length !== 1 || branches[0] !== 'main') { failed = true; console.error('FAIL: use exactly one branch, main. Commit once if the branch is unborn.'); }
  else console.log('PASS: one local branch (main).');
  const tracked = git(['ls-files']).split('\n');
  if (tracked.some(file => /(^|\/)\.env(\.|$)/.test(file) && file !== '.env.example')) { failed = true; console.error('FAIL: a secret environment file is tracked. Remove it before pushing.'); }
  else console.log('PASS: no .env secret file tracked.');
} catch { console.log('PENDING: copy files into your cloned GitHub repository, then commit on main.'); }
if (process.argv.includes('--remote')) {
  try {
    const remote = git(['remote', 'get-url', 'origin']);
    const match = remote.match(/github\.com[:/]([^/]+)\/([^/]+?)(?:\.git)?$/);
    if (!match) throw new Error('Set origin to your GitHub repository first.');
    const endpoint = `https://api.github.com/repos/${match[1]}/${match[2]}`;
    const r = await fetch(endpoint, { signal: AbortSignal.timeout(10000), headers: { 'User-Agent': 'thozhi-submission-check' } });
    if (!r.ok) throw new Error('Repository is not publicly readable, does not exist, or GitHub rate-limited this check.');
    const repo = await r.json();
    if (repo.private) throw new Error('Repository is private.');
    const br = await fetch(`${endpoint}/branches?per_page=100`, { signal: AbortSignal.timeout(10000), headers: { 'User-Agent': 'thozhi-submission-check' } });
    if (!br.ok) throw new Error('Could not inspect remote branches.');
    const branches = await br.json();
    if (branches.length !== 1 || branches[0].name !== 'main') throw new Error('Remote must contain exactly one branch, main.');
    if (repo.size * 1024 >= 10000000) throw new Error('GitHub reports a repository size at or above the limit.');
    console.log('PASS: GitHub repository is public, has one branch (main), and reports under 10 MB.');
  } catch (error) { failed = true; console.error(`REMOTE CHECK: ${error.message}`); }
} else console.log('PENDING: after pushing, run npm run check:submission -- --remote to check public visibility and remote branches.');
console.log('Do not submit until local tests and all required GitHub checks pass. You have at most two submission attempts.');
if (failed) process.exitCode = 1;
