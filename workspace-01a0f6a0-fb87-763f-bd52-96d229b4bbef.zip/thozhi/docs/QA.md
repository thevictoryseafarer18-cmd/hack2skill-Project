# QA and remaining validation

Date: **1 October 2026**

## Latest workspace validation

- **187** Node regression tests passed.
- **144 new hub/browser checks passed** on v2.0. Earlier v1.2 checks passed 51 original, 128 multilingual and 28 app/web scenarios; those counts are historical, not proof of the expanded hub.
- The earlier v1.1 scoped axe-core 4.10.3 automated check found **zero detected violations** for its selected WCAG 2/2.1 A/AA rules on eight desktop states (welcome, question, documents, next step, help, route, privacy, sources) plus welcome screens in all six new languages. See `accessibility-check.json`. This is not a full accessibility audit or certification, and predates the v1.2 photographic design; a current full accessibility/linguistic/real-device audit remains required.
- The standalone exported HTML completed the eligibility journey with the browser offline. Its inline UI, Tamil audio, and tap-through journey also worked in an `allow-scripts`-only sandboxed iframe matching the file viewer. External tabs, microphone permissions, and downloads may be restricted by a viewer; use the live server or open the downloaded HTML in a normal browser for those actions.
- **Actual microphone hardware/cloud recognition, regional TTS pronunciation/availability on real devices, and live Gemini were not tested.** Those remain explicit manual checks.

## Reproducible automated checks

### 1. Core rules, local AI, privacy, HTTP, and external-AI contract

```bash
npm test
```

Uses Node's built-in test runner. No dependency installation or API key required. The tests cover positive/negative/unknown basic eligibility, the one-question transition model, approved sources, checklist disclaimers, Tamil/Tanglish intent examples and held-out phrase variants, identifier redaction, and static/API safety.

Optional Gemini behavior is tested with a **mocked transport**: consent is required, question text is redacted, only allowlisted intents are accepted, answers remain curated, and provider failures fall back locally. This is not a live Gemini test.

### 2. Real-browser application behavior

With the app running:

```bash
python -m pip install playwright
python -m playwright install --with-deps chromium
python scripts/browser-check.py
```

Python/Playwright is an optional QA tool, **not an application dependency** and not bundled in the repository. The original script writes two screenshots and `docs/browser-checks.json`. Also run `python scripts/multilingual-browser-check.py` for localized journeys, language switching without data loss, speech-locale contracts, new-language offline flows, and responsiveness in all eight text options; its exact results are in `docs/multilingual-browser-checks.json`. Regional speech API checks use mocks, not actual cloud/hardware services.

Automated browser checks include:
- Tanglish startup and Tamil-script switching.
- Real browser MP3 decoding for all ten clips and actual welcome-audio playback start.
- Manual completion, confirm/reject of interpreted answers, negative conditions, and unknown answers.
- Back preserving document selections; Restart clearing the journey.
- Local FAQ, unknown-query rejection, no identifier echo, and no answer storage.
- Downloaded checklist contents and explicit no-submission caveat.
- Official-link interstitial and legitimate in-person route.
- Recognition callbacks tested with a **mocked Tamil transcript** and an unsupported-browser fallback.
- Service-worker cache excluding API/personal data; offline reload, local FAQ, and full eligibility journey.
- No horizontal overflow at 320, 360, 390, 768, 1024, and 1440 pixels in both text languages.
- Primary voice CTA visible on a 360×640 viewport.
- No uncaught JavaScript errors in these scenarios.

Use the JSON report for the exact check count/results of the latest run. Passing these tests is **not** proof of actual speech recognition accuracy, screen-reader compatibility on every phone, field usability, or end-to-end government-service completion.

### 3. Repository preflight

```bash
npm run check:submission
npm run check:submission -- --remote
```

Local size/branch/secret checks work before submission. GitHub visibility and remote branch checks require the user to create and push a public repository first. No remote/public check has been claimed for this workspace.

## Manual checks still required before a real pilot

- Actual Android Chrome/Edge microphone permission, denied permission, Tamil pronunciation, ambient noise, spoken Tanglish code-switching, and browser cloud-recognition availability.
- Confirm spoken-answer accuracy and whether first-time users understand confirmation; the bundled confirmation prompt does not always read out an inferred answer when the phone has no Tamil TTS voice.
- Full listening experience on cheap phone speakers, with and without internet after caching.
- Low-cost devices, shared-phone privacy, file download/deletion, and large text/zoom.
- VoiceOver/TalkBack, meaningful focus order, and full WCAG audit. No certification is claimed.
- Native-speaker linguistic review for Tamil, Hindi, Telugu, Kannada, Malayalam, Bengali, and Marathi by women in the intended communities. No such field review has been conducted.
- Clear consent and the provider's retention terms if optional Gemini is enabled; actual Gemini account/quota/model availability.
- Official sites' current forms, supported languages, application windows, and current requirements. External forms may still have captcha/OTP and are outside the app.
- Actual public GitHub visibility, one remote branch, and repository size.

## Pilot success criteria

The key outcome is **independent understanding and action**, not chatbot message count:

1. User can start without someone explaining how.
2. User can understand the current question and select/confirm her own answer.
3. User can recover from a mistake, uncertainty, or microphone failure.
4. User can identify the necessary documents and the correct official next step.
5. User understands that Thozhi has not submitted a form or promised approval.
6. User can follow the official online route or independently approach a distributor.

Do not report field-study results until such a study has actually taken place.

## App / web edition checks

`python scripts/app-web-browser-check.py` validates actual 4K image decoding, mobile responsive imagery, bottom app navigation, start controls remaining above the app bar on 360×640 in all eight text options, installed-state handling, localized install guidance, and offline imagery/navigation. The browser install-prompt contract is mocked. **Actual OS installation was not tested** and no app-store/APK release is claimed. See `app-web-browser-checks.json`.

## v2.0 India-wide hub

`python scripts/hub-browser-check.py` checks 17 service routes, 36 state/UT directory options, all six lessons, three harmless practice flows, study/service downloads, allowlisted external handoffs, actual new Tamil audio playback, no answer storage, original gas-journey preservation, all eight text choices, six screen widths, short-phone first actions, and offline hub/learning behavior. The latest report is `hub-browser-checks.json`. Official government applications, clinical care, account opening and benefit approval were not performed.
