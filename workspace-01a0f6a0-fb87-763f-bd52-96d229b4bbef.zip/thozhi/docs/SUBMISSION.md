# Submit Thozhi without wasting an attempt

The challenge rules supplied by you are:
- **At most two submission attempts.**
- **Repository less than 10 MB.**
- **Public GitHub repository.**
- **Exactly one branch.**
- Clone and work on the repository inside **Antigravity**, then push and submit its public link.

No repository has been published or submission made by this assistant. You need to complete these steps using your own GitHub and Antigravity accounts.

## 1. Create a new public GitHub repository

Name it `thozhi` (or your preferred name). Select **Public**. Leave the “Add README / .gitignore / License” boxes unchecked: these files are already included. Use `main` as the default branch.

GitHub's guide: https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository

## 2. Clone inside Antigravity

Open Antigravity and clone the new repository using its repository URL:

```bash
git clone https://github.com/YOUR_USERNAME/thozhi.git
cd thozhi
```

Antigravity setup: https://antigravity.google/docs/get-started

Unzip the supplied `Thozhi-source.zip`. Copy the **contents** of its `thozhi/` directory into your cloned repository. Include `.gitignore` and `.env.example`; hidden files may be hidden by your file manager. Do not copy another `.git` directory or place the whole project in a second nested `thozhi` folder.

If the empty repository has not chosen a branch yet:

```bash
git branch -M main
```

Keep all work on **main**. Do not create development/feature branches.

## 3. Use Antigravity to run, inspect, and refine

A suitable Antigravity prompt:

> Read README.md and docs/SOURCES.md. Run npm test and npm start. Keep all work on the main branch. Review the Tamil/Tanglish first-time-user journey and mobile layout without adding large dependencies. Preserve the official PMUY rule engine, no-secret policy, offline audio, and explicit application handoff. Do not claim approval or invent nearby agencies. Keep the complete repository below 10 MB. Ask before changing any verified scheme rule.

The starter was prepared here; if your challenge specifically requires all development to take place in Antigravity, use it to review, modify, test, and finalize the project and verify any provenance requirements with the organizers. Do not claim a different development history.

Run:

```bash
npm test
npm start
```

You do **not** need an API key or `npm install` for the default local AI. Optional Gemini configuration is described in README.md. Never commit `.env`.

## 4. Test before pushing

Follow `docs/DEMO.md` and `docs/QA.md`. On a real Android phone, use an HTTPS deployment and test microphone permission, actual Tamil recognition, Tamil audio, large-button fallback, and offline reload.

Do not send an actual government application just to demonstrate the prototype.

## 5. Commit and push, on one branch

From the cloned repository:

```bash
git status
git add .
git commit -m "Build Thozhi Tamil voice-first PMUY guide"
git push -u origin main
```

If `git add .` includes `.env`, credentials, caches, video recordings, or dependencies, stop and fix the ignore rules before committing. Do not include this ZIP inside the repository.

## 6. Preflight

```bash
npm test
npm run check:submission
npm run check:submission -- --remote
git branch -a
```

The remote preflight uses GitHub's unauthenticated API to check public visibility, branch count, and reported size. If GitHub rate-limits it, manually check those properties on GitHub. Do not treat a pending/failed remote check as a pass.

Expected branch listing after push:

```text
* main
  remotes/origin/main
```

A symbolic `remotes/origin/HEAD -> origin/main` is not a second branch. Check GitHub → branches: exactly **one actual branch**. If extra branches already exist, inspect them and safely remove only the ones you do not need; do not run destructive commands blindly.

The local checker conservatively adds source/assets and the local `.git` history. Repeated replacement of large audio files can grow Git history even if the current working tree is small. Avoid committing generated caches and keep a clean, small submission history.

## 7. Final visual verification, signed out

Open the GitHub repository in a private/incognito browser window. Confirm:
- It is visible without signing in.
- README shows how to run and what the app actually does.
- All source and the Tamil MP3 files are present.
- The branch list has only main.
- No key, password, personal data, or real government documents are present.
- The repository is under 10 MB.

## 8. Submit only when ready

Copy:

```text
https://github.com/YOUR_USERNAME/thozhi
```

Submit this **public repository URL** in the challenge's Submissions tab. Do not submit the Arena preview URL or the ZIP. This code preparation is not a submission attempt. You have at most **two** actual submission attempts.
