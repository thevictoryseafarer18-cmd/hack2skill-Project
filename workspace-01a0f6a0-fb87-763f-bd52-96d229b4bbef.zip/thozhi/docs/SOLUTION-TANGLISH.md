# Thozhi — unga digital thunai

## Oru vari-la idea

**Internet use panna theriyaadha oru pen, Tamil-la pesi alladhu periya button-ai thottu, Ujjwala gas connection-kku eppadi vinnappikkanum-nu purinjukka udhavum AI thunai.**

## Enna problem-ai solve panrom?

English website, periya form, technical vaarthaigal — idhellaam mudhal murai use panravangalukku kashtam. Kudumbathula yaaravadhu udhavi seiyanum-nu kaathirukka vendiya nilai varalaam.

Thozhi indha kuzhappathai kuraikkum. Oru nerathula **oru chinna padi** mattum kaattum.

## Oru pen eppadi use pannuvaanga?

1. **“Enakku gas connection venum”** nu Tamil-la solluvaanga. Pesama thodangum button-um irukku.
2. Thozhi **moondru chinna kelvigal** ketkum. Aama, illai, theriyala — idhula oru badhil podhum.
3. Thozhi **adippadai thagudhi conditions** porundhudhaa-nu vilakkum. Idhu final approval illa.
4. **Enna aavanangal kondu poganum**-nu eliya pattiyal kaattum. Aavanangalai inge upload panna vendaam.
5. **Official website vazhi** alladhu **gas agency-ku neril pogum vazhi** kaattum.
6. Adutha-padi pattiyalai phone-la saemichukkalaam.

## AI enna seiyum?

“Ration card illa”, “Enna aavanangal venum”, “Enakku English theriyaadhu” maadhiri kelvigalai purinjukka muyarchi seiyum. Adharku sariyana, munnaadi saripaartha badhilai kaattum.

**AI arasu rules-ai uruvaakkaadhu. Approval kudukkaadhu. Puriyala-na, puriyala-nu sollum.**

## Indha solution yen poruthamaanadhu?

- Tanglish default. Tamil, Hindi, Telugu, Kannada, Malayalam, Bengali, Marathi text option-galum irukku. Tamil audio inge irukku; pudhu mozhigalin kural phone-la irundhaal payanpaduthalaam. Kural illai-na button/text vazhiyai thodaralaam.
- Login, email, password thevai illai.
- Periya button-gal. Oru nerathula oru kelvi.
- Kural-la ketta badhilai user urudhi pannina piragudhaan payanpaduthum.
- Thappu-na pinnadi poi maathalaam.
- Aadhaar en, bank en, OTP ketkaadhu.
- Mudhal load-um cache-um mudindha piragu, mukkiya vazhikaatti, local AI, Tamil audio internet illaama velai seiyum.
- Browser kural sevaiyum official website-um internet-ai payanpaduthalaam.
- Official online form kashtamaa irundhaa, thaniya neril vinnappikkum vazhi irukku.

## Mukkiya unmai

Thozhi **arasu website illa**. Inge **vinnappam anuppappadavillai**. Final thagudhi, aavanangal, ippodhaya vinnappa vaaippu — idhai gas agency / official sevai dhaan urudhi seiyum.

Indha prototype mudhal-murai pengal use panna elidhaa irukkum-nu design pannirukkom. Aana, avangaloda nijamaana user testing innum seiyanum.

## Judges-kku solla vendiya mukkiya vari

> “Thozhi oru chatbot mattum illa. Oru pen purinjukittu, avale adutha padi edukka udhavum Tamil digital thunai.”
