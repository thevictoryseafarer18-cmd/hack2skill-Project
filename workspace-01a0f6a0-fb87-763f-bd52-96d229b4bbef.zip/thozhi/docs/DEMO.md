# Thozhi v2.0 — India-wide digital companion

## One line
A rural woman can choose a government service in her language, prepare her next step, and learn safe internet use without entering private numbers into a chatbot.

## Two-minute demo
1. Show the two big homepage choices: services and Internet learning.
2. Open Aadhaar or ration: explain preparation, five generic steps, current-rules caveat, correct offline office and explicit official handoff.
3. Show the 36-state/UT directory selector. It is a directory route, not one universal state procedure.
4. Open the six internet lessons. Complete sample-word form or OTP scam practice. No real transaction occurs.
5. Save study notes; show official course/PDF references.
6. Switch Hindi/Telugu/Tamil. Original PMUY detailed guide is still available under Gas.
7. State the boundaries: no application, payment, approval, guaranteed benefit, government affiliation, or certification.

New Tamil hub/learning introductions are bundled. Regional voices and detailed narration depend on the phone. Validate speech, translations, official forms and first-time-user behavior before a pilot.

# Thozhi — a simple demo and pitch

## One-line idea

**Thozhi is a Tamil-speaking digital friend that turns one confusing government-service journey into small, understandable steps a woman can take herself.**

## Why Ujjwala?

A new LPG connection is a concrete household service. The official PMUY journey has a small set of basic conditions, an identifiable document list, and both online and distributor application routes. That makes it suitable for a focused, honest prototype rather than a chatbot that offers dozens of unverified schemes.

## 90-second spoken pitch (English)

Many women do not need someone to tell them they are capable. They need systems designed so they can act independently.

Meet Thozhi—Tamil for a female friend. It helps a first-time user prepare to access the Ujjwala LPG scheme without knowing English, creating an account, or depending on a male family member.

She can say, “Enakku gas connection venum,” or simply touch a large button. Thozhi asks one question at a time in Tamil. It accepts yes, no, or don't know. It confirms recognized answers before using them, explains the required documents, and gives her a next-step checklist.

Then it opens a verified official application route or explains how she can apply herself at a gas distributor. If the official online form is difficult, she is not stuck.

Our lightweight intent AI works without an API key. The core guide and recorded Tamil instructions work offline after the first load. Scheme rules and answers come from checked official information, not an AI guessing benefits or promising approval.

Thozhi never asks for Aadhaar numbers, OTPs, passwords, or document uploads. It does not claim to submit an application. Its purpose is simple: give a woman the understanding, confidence, and correct next step to act herself.

## 2-minute working demo

### 0:00 — Meet Thozhi

Show the Tanglish welcome screen and the colourful native-script language cards. Select Hindi or Telugu briefly to demonstrate that questions, safety text, FAQs, and checklist also translate—not only the language menu. Return to Tanglish for the bundled Tamil audio demo. Tap **Kelu** to play the built-in Tamil introduction. Point out the large microphone and **Pesama thodangalaam** alternative. No login exists.

### 0:20 — Begin a real task

On a supported, HTTPS-enabled phone, say **“Enakku gas connection venum.”** Confirm the recognized request. If recognition is unavailable, tap **Pesama thodangalaam**; the same journey still works.

### 0:40 — Answer three small questions

Use this clearly labelled demonstration scenario, not a real person's details:

1. Applicant is a woman who has attained 18 → **Aama**.
2. Household already has an LPG connection → **Illai**.
3. Poor-household application → **Aama**.

Show the outcome: **basic conditions may match; final verification is still required**. Also show that **Theriyala** is allowed and that answers can be changed with Back.

### 1:05 — Understand the documents

Open the checklist. Tap **Idhu enna?** under a document to reveal its explanation. Mark one document as ready. Do not enter an Aadhaar or bank number—there is no field for them.

Ask **“Ration card illa”** in the simple question box. The guide explains other state family documents and the specific migrant self-declaration provision; it does not tell everyone to skip requirements.

### 1:30 — Get a useful next step

Continue to **Adutha padi**. Save the checklist. Open the in-person route to see the exact sentence to say at a distributor and the forms to ask for. Open the online route's interstitial to show the allowlisted official domain.

**Stop before any real application or government login.** There is no fabricated application confirmation.

### 1:50 — Show resilience

Switch the text to Tamil or another language. Explain that Tamil audio is bundled, while the new languages use the phone's matching voice if installed; the guide never plays Tamil audio for a Hindi user. After the offline cache is ready, disconnect the internet and reload. Show that the large-button guide, local AI, and bundled audio remain available. Explain that browser recognition and external official websites may still need internet.

## Explain the AI without jargon

“Thozhi learns which kind of help the user is asking for from small examples of Tamil and Tanglish questions. It chooses the right verified explanation. The AI is not allowed to make up government rules.”

## Honest boundaries to say to judges

- This is a functioning, single-service prototype—not a government-authorized application portal.
- Actual approval, KYC, and current allocation are controlled by the official provider.
- Actual microphone recognition and regional TTS depend on browser support, available voices, permissions, and connectivity.
- Optional Gemini intent fallback needs a private key; it was not live-tested in the default demo.
- Independent use must be validated with first-time women users; we have not conducted that field study.

## What to measure in a pilot

- Can she start without help?
- Does she understand the yes/no questions and poverty declaration caveat?
- Can she recover from an incorrect answer or denied microphone permission?
- Does she understand that no application has been submitted yet?
- Can she identify the documents and act on the official next step?
- What fails on a low-cost Android phone or a shared device?
