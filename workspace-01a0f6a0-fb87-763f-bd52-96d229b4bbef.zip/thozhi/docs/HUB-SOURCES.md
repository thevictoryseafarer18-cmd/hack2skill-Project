# India-wide services and internet learning — source register

Checked **1 October 2026**. Thozhi provides navigation and preparation, not official applications or eligibility decisions (except the existing basic PMUY check, which is still not approval).

## Government-service routes

- Aadhaar: [UIDAI update FAQ](https://uidai.gov.in/en/297-english-uk/faqs/enrolment-update/aadhaar-updation.html), [MyAadhaar](https://myaadhaar.uidai.gov.in/). UIDAI says online address/document updates are available; not every update is online.
- Ration/PDS: [NFSA application guidance](https://nfsa.gov.in/portal/apply_ration_card). Card issuance and applicant identification are handled by states/UTs.
- LPG: [official PMUY requirements](https://www.pmuy.gov.in/ujjwala2.html). The original connection-preparation guide remains; it does not book refills.
- Health card: [NHA beneficiary portal](https://beneficiary.nha.gov.in/). No universal coverage, benefit amount or eligibility promise is encoded.
- Doctor access: [Digital India eSanjeevani](https://www.digitalindia.gov.in/initiative/esanjeevani/) links the [MoHFW service](https://esanjeevani.mohfw.gov.in/#/). No diagnosis or emergency telemedicine promise.
- Pensions: [official PIB NSAP overview](https://www.pib.gov.in/PressNoteDetails.aspx?ModuleId=3&NoteId=155928&lang=2&reg=3), [NSAP](https://nsap.nic.in/). State conditions/amounts are not generalized.
- Rural work: [Ministry of Rural Development / PIB 30 June 2026 notice](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2279446&reg=48&lang=2). Current guide names VB-G RAM G and refers workers to Panchayat/block authorities. No obsolete 100-day promise or guessed wage is used.
- Worker registration: [e-Shram](https://eshram.gov.in/), [official registration](https://register.eshram.gov.in/#/user/self). Registration is not a cash-benefit guarantee.
- Banking: [PMJDY](https://pmjdy.gov.in/), [scheme](https://pmjdy.gov.in/scheme). Account opening remains at the bank/authorized Bank Mitra.
- Women's self-help groups: [official DAY-NRLM briefing](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2023/dec/doc2023126279701.pdf), [Aajeevika](https://aajeevika.gov.in/).
- Scholarships: [NSP](https://scholarships.gov.in/). OTR and scheme-specific dates/documents must be checked there; no one universal scholarship checklist/deadline.
- Skills/study: [Skill India](https://www.skillindiadigital.gov.in/), [SWAYAM](https://swayam.gov.in/), [DIKSHA](https://diksha.gov.in/). Certificates/exams/particular courses may involve fees.
- Documents: [DigiLocker](https://www.digilocker.gov.in/), [Digital India overview](https://www.digitalindia.gov.in/initiative/digilocker/). Issued documents and personally scanned uploads are not equated.
- Other services/certificates/bills/grievances: [myScheme](https://www.myscheme.gov.in/), [UMANG](https://web.umang.gov.in/), [National Portal services](https://www.india.gov.in/services), [CPGRAMS](https://pgportal.gov.in/).
- Maternity/child support: [PMMVY](https://pmmvy.wcd.gov.in/) and myScheme; verify with Anganwadi/WCD. No universal benefit promise.
- Housing: [PMAY-G](https://pmayg.dord.gov.in/) and myScheme; verify current local survey/eligibility with Panchayat/block housing office.
- Farmers: [PM-KISAN](https://pmkisan.gov.in/). Registration, exclusions, verification and eKYC are official processes; not all farmers are entitled.

The complete 36-state/UT directory code list comes from [iGOD](https://igod.gov.in/sg/states). These are official **directory** links, not invented state application endpoints.

## Beginner study resources

- [NIELIT HQ](https://www.nielit.gov.in/NielitMain/HQ) and [CCC/BCC e-content](https://econtent.nielit.gov.in/start.php). e-content access may require registration. Old `/content/` links now redirect or fail; the old pages are not advertised as current enrollment windows.
- [CERT-In Mahila Suraksha handbook PDF](https://www.cert-in.org.in/PDF/Mahila_Suraksha_Booklet25.pdf), confirmed by [PIB announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2109192&reg=48&lang=2).
- [NCW Cyber Saheli PDF](https://cdn.ncw.gov.in/wp-content/uploads/2025/05/CyberSaheli.pdf).
- [NPCI fraud awareness](https://www.npci.org.in/fraud-awareness). Its cashback warning explains that QR scan + UPI PIN is for paying, not receiving money.
- [National Cyber Crime Reporting Portal](https://cybercrime.gov.in/Webform/Accept.aspx): cybercrime helpline 1930; emergency/police 112. No refund is guaranteed.
- DIKSHA textbooks/videos and SWAYAM course catalog are external enrichment resources, not claims that every course is beginner-level or available in every language.

The six offline lessons and practice activities are **original plain-language material**, not reproduced government textbooks or a government certificate. Notes download as UTF-8 text. No real transaction or application occurs in practice.

## Verification limits

Several government sites are JS-heavy or restricted automated retrieval (including NHA, PMMVY, PMAY-G, NSAP/Aajeevika and PDF hosts). Their official ownership/routes are sourced above; complete live forms, logins, current admissions and end-to-end government submissions were **not** tested. External links may change. Before a pilot, validate the target state's current departmental procedures, links, language availability, costs, and permissions with real users. Do not use lookalike Aadhaar/Ayushman/NSP websites that appeared in web search.
