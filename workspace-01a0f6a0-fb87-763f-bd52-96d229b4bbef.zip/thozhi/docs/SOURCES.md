# Scheme sources and safeguards

**Knowledge snapshot checked: 1 October 2026.** Re-check before a public deployment. This is not an official government product.

Only primary PMUY pages were used for application rules. Third-party claims about subsidy amounts were deliberately excluded.

## 1. New PMUY / Ujjwala connection

https://www.pmuy.gov.in/ujjwala2.html

Used for:
- Applicant is a woman who has attained 18 years of age.
- No LPG connection from any Oil Marketing Company in the same household.
- Adult woman belongs to a poor household, supported by the prescribed deprivation declaration.
- KYC application; applicant Aadhaar; Aadhaar copies of adult family members listed in the family document; state ration card or another state family-composition document; bank passbook copy or cancelled cheque; address proof if the Aadhaar address differs; deprivation declaration.
- Annexure I self-declaration facility for migrant applicants, where specified. This is **not** a general permission for every applicant to skip a ration card or address proof.
- Applicant may submit at a distributor of her choice or use an online portal.
- Official online handoffs to Indane, Bharatgas, and HP Gas, extracted from the same page.
- The visible page header labels **14438** as the Ujjwala helpline and **1906** as LPG emergency. Its older telephone href still uses 1800-266-6696; the app uses the visible short number, 14438.

## 2. Official PMUY home

https://www.pmuy.gov.in/index.aspx

Used for:
- Official distributor-search handoffs to Indane and Bharatgas.
- Consumer information and scheme context.
- Current benefit/fee information must be reconfirmed here or with the distributor. The guide does not hard-code a subsidy amount, guarantee free future refills, or assume an open allocation window.

## 3. Official KYC form

https://www.pmuy.gov.in/documents/KYC.pdf

Included as an allowlisted official resource. No government PDF or logo is bundled, no document is uploaded, and no form is submitted by Thozhi.

## What the guide does not claim

- A basic check is **not** final eligibility, approval, or a booking.
- An existing LPG connection in any household member's name matters; a woman not personally owning one is insufficient.
- Poverty is self-reported only for routing; the prescribed declaration and official verification still apply.
- Distributor verification, availability, and official KYC/OTP are outside this app.
- No application ID is invented, and no fake distributor, distance, map pin, or deadline is displayed.

## Updating information

Edit `public/lib/scheme.js`, re-verify every external URL, update `version` and `verifiedAt`, recheck the Tamil audio against the new text, and increment the cache name in `public/sw.js`. Run all tests. Because facts and audio are bundled, a maintainer must update the snapshot when rules change.

## Asset attribution

- Companion illustration and logo: original SVG assets in this project.
- Tamil audio: AI-synthesized narration using a user-selected feminine Tamil voice; not a real government official's recording.
- DM Sans, Noto Sans Tamil, Noto Sans Devanagari (Hindi/Marathi), Noto Sans Telugu, Kannada, Malayalam, and Bengali: Google Fonts, SIL Open Font License; all licenses bundled in `public/assets/fonts/`.
- The six additional languages use native UI/FAQ/checklist translations of the same source rules, not different schemes. They require native-speaker review before a pilot.
- Regional readout uses phone/browser TTS when available; no regional recording or voice model is bundled. ASR/TTS providers may require internet.

The digital-exclusion statistic in the challenge was supplied by the user; Thozhi does not present it as independently verified research.

## App/web background imagery

Two original AI-generated illustrative photos were created for this prototype: an adult Indian woman independently using a smartphone, and a calm kitchen with an LPG stove. They are not real beneficiary photographs or government endorsements. The kitchen scene must not be treated as a gas-installation guide. Images are resampled from 1672×941 generated originals to **3840×2160 WebP** delivery dimensions; a 960×540 rendition serves mobile layouts. Pixel dimensions are tested, but native 4K generation/capture is not claimed. Provenance and byte sizes are in `public/assets/images/images.json`.
