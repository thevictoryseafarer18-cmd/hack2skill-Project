import test from 'node:test';
import assert from 'node:assert/strict';
import { LANGUAGES, UI_TRANSLATIONS } from '../public/lib/locales.js';
import { QUESTIONS, DOCUMENTS, FAQ, eligibility, makeChecklist, newJourney } from '../public/lib/scheme.js';
import { SCHEME_TRANSLATIONS } from '../public/lib/scheme-translations.js';
import { classifyIntent, detectAnswer, redactSensitive } from '../public/lib/intent-model.js';

const baseKeys = Object.keys(UI_TRANSLATIONS.tl).sort();
test('seven Indian languages plus Roman Tamil, not eight distinct languages', () => { assert.equal(LANGUAGES.length,8); assert.equal(new Set(LANGUAGES.map(l=>l.voicePrefix)).size,7); });
for (const language of LANGUAGES) {
  test(`${language.name}: every UI string is translated, no silent Tanglish fallback`, () => {
    const strings=UI_TRANSLATIONS[language.id]; assert.deepEqual(Object.keys(strings).sort(),baseKeys);
    assert.ok(Object.values(strings).every(v=>typeof v==='string'&&v.trim().length));
  });
  test(`${language.name}: all questions, documents, and FAQs exist`, () => {
    for (const q of QUESTIONS) { assert.ok(q.title[language.id]); assert.ok(q.note[language.id]); }
    for (const d of DOCUMENTS) { assert.ok(d.name[language.id]); assert.ok(d.detail[language.id]); }
    for (const f of Object.values(FAQ)) { assert.ok(f.title[language.id]); assert.ok(f.text[language.id]); }
  });
  test(`${language.name}: checklist includes native documents and unchanged official URL`, () => {
    const state={...newJourney(),answers:{adult:'yes',lpg:'no',poor:'yes'},ready:['aadhaar']};
    const plan=makeChecklist(state,language.id); assert.ok(plan.includes(DOCUMENTS[0].name[language.id]));
    assert.ok(plan.includes('https://www.pmuy.gov.in/ujjwala2.html')); assert.equal(eligibility(state.answers),'potential');
    if (SCHEME_TRANSLATIONS[language.id]) assert.ok(plan.includes(SCHEME_TRANSLATIONS[language.id].checklist.noApproval));
  });
  test(`${language.name}: speech locale follows selected language; bundled clips are Tamil only`, () => {
    assert.ok(language.speech.endsWith('-IN')); assert.equal(language.bundled,language.voicePrefix==='ta');
  });
}
for (const [text,intent] of [
  ['मुझे गैस कनेक्शन चाहिए','start'],['कौन से कागज़ात चाहिए','documents'],['राशन कार्ड नहीं है','missing_ration'],
  ['నాకు గ్యాస్ కనెక్షన్ కావాలి','start'],['ఏ పత్రాలు కావాలి','documents'],['రేషన్ కార్డు లేదు','missing_ration'],
  ['ನನಗೆ ಗ್ಯಾಸ್ ಸಂಪರ್ಕ ಬೇಕು','start'],['ಯಾವ ದಾಖಲೆಗಳು ಬೇಕು','documents'],['ರೇಷನ್ ಕಾರ್ಡ್ ಇಲ್ಲ','missing_ration'],
  ['എനിക്ക് ഗ്യാസ് കണക്ഷൻ വേണം','start'],['ഏത് രേഖകൾ വേണം','documents'],['റേഷൻ കാർഡ് ഇല്ല','missing_ration'],
  ['আমার গ্যাস সংযোগ চাই','start'],['কোন নথি লাগবে','documents'],['রেশন কার্ড নেই','missing_ration'],
  ['मला गॅस जोडणी हवी','start'],['कोणती कागदपत्रे हवी','documents'],['रेशन कार्ड नाही','missing_ration']
]) test(`Regional intent: ${text}`,()=>assert.equal(classifyIntent(text).intent,intent));
for (const [yes,no,unsure] of [['हाँ','नहीं','पता नहीं'],['అవును','లేదు','తెలియదు'],['ಹೌದು','ಇಲ್ಲ','ಗೊತ್ತಿಲ್ಲ'],['അതെ','ഇല്ല','അറിയില്ല'],['হ্যাঁ','না','জানি না'],['होय','नाही','माहीत नाही']]) {
  test(`Regional answers: ${yes} / ${no} / ${unsure}`,()=>{
    assert.equal(detectAnswer(yes,'adult'),'yes'); assert.equal(detectAnswer(no,'lpg'),'no'); assert.equal(detectAnswer(unsure,'poor'),'unsure');
    assert.equal(detectAnswer(`${yes} ${no}`,'adult'),null);
  });
}
test('Indian-script identifiers are redacted, while ordinary ages remain usable',()=>{
  for (const number of ['१२३४५६७८९०१२','১২৩৪৫৬৭৮৯০১২','౧౨౩౪౫౬౭౮౯౦౧౨','೧೨೩೪೫೬೭೮೯೦೧೨','൧൨൩൪൫൬൭൮൯൦൧൨']) assert.equal(redactSensitive(number),'[number hidden]');
  assert.equal(detectAnswer('उम्र १८','adult'),'yes'); assert.equal(detectAnswer('वय १७','adult'),'no');
});
test('missing-document phrases never become eligibility answers in regional languages',()=>{
  for (const text of ['आधार नहीं है','ఆధార్ లేదు','ಆಧಾರ್ ಇಲ್ಲ','ആധാർ ഇല്ല','আধার নেই','आधार नाही']) assert.equal(detectAnswer(text,'adult'),null);
});
test('presence after Hindi negation does not override no',()=>assert.equal(detectAnswer('नहीं है','lpg'),'no'));
