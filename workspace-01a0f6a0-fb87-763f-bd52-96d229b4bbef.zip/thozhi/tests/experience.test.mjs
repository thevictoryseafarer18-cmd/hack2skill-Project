import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { LANGUAGES, UI_TRANSLATIONS } from '../public/lib/locales.js';
import { EXPERIENCE_UI } from '../public/lib/experience-ui.js';
const root = new URL('../public/', import.meta.url);

function webpSize(buffer) {
  assert.equal(buffer.toString('ascii', 0, 4), 'RIFF');
  assert.equal(buffer.toString('ascii', 8, 12), 'WEBP');
  for (let offset=12; offset<buffer.length; ) {
    const type=buffer.toString('ascii',offset,offset+4), len=buffer.readUInt32LE(offset+4), data=offset+8;
    if (type==='VP8 ') return [buffer.readUInt16LE(data+6)&0x3fff, buffer.readUInt16LE(data+8)&0x3fff];
    if (type==='VP8X') return [1+buffer.readUIntLE(data+4,3),1+buffer.readUIntLE(data+7,3)];
    offset=data+len+(len%2);
  }
  throw Error('No supported WebP image header');
}
for (const name of ['independent-woman-4k.webp','clean-kitchen-4k.webp']) test(`${name}: real 3840×2160 WebP dimensions, compressed below 300 KB`,async()=>{
  const file=await readFile(new URL(`assets/images/${name}`,root));
  assert.deepEqual(webpSize(file),[3840,2160]);assert.ok(file.length<300000);
});
test('phone rendition avoids decoding a 4K image for a small photo banner',async()=>{
  const file=await readFile(new URL('assets/images/independent-woman-mobile.webp',root));
  assert.deepEqual(webpSize(file),[960,540]);assert.ok(file.length<50000);
});
test('image provenance honestly discloses upsampling and illustration status',async()=>{
  const images=JSON.parse(await readFile(new URL('assets/images/images.json',root),'utf8'));
  assert.equal(images.length,2);assert.ok(images.every(i=>i.upsampled===true&&i.originalGeneratedSize[0]===1672&&i.width===3840));
});
test('manifest supports home-screen standalone app with local icons, not an APK',async()=>{
  const manifest=JSON.parse(await readFile(new URL('manifest.webmanifest',root),'utf8'));
  assert.equal(manifest.display,'standalone');assert.equal(manifest.start_url,'/');assert.equal(manifest.scope,'/');
  for (const icon of manifest.icons) {assert.ok(icon.src.startsWith('/assets/'));assert.ok((await readFile(new URL(icon.src.slice(1),root))).length);}
});
test('every language gets the same localized platform controls without approval promises',()=>{
  const keys=Object.keys(EXPERIENCE_UI.tl).sort();
  for (const l of LANGUAGES) {assert.deepEqual(Object.keys(EXPERIENCE_UI[l.id]).sort(),keys);assert.equal(UI_TRANSLATIONS[l.id].installTitle,EXPERIENCE_UI[l.id].installTitle);assert.ok(EXPERIENCE_UI[l.id].installCopy.includes('APK'));}
});
test('app assets and new photo backgrounds are included in the offline public cache',async()=>{
  const sw=await readFile(new URL('sw.js',root),'utf8');
  for (const url of ['/experience.css','/lib/experience-ui.js','/assets/images/independent-woman-4k.webp','/assets/images/clean-kitchen-4k.webp'])assert.ok(sw.includes(url));
  assert.ok(sw.includes("url.pathname.startsWith('/api/')"));
});
