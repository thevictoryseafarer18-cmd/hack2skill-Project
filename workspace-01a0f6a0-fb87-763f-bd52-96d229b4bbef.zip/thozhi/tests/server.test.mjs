import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from '../server.mjs';
let server, base;
before(async () => { server = createServer(); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); base = `http://127.0.0.1:${server.address().port}`; });
after(async () => { await new Promise(resolve => server.close(resolve)); });
const post = body => fetch(`${base}/api/assist`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
test('home page, assets, and defensive headers are served', async () => {
  const r = await fetch(base); assert.equal(r.status, 200); assert.match(await r.text(), /Thozhi/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff'); assert.ok(r.headers.get('content-security-policy'));
  assert.equal(r.headers.get('x-frame-options'), null);
});
test('health exposes mode, not a secret', async () => {
  const r = await fetch(`${base}/api/health`); const body = await r.json();
  assert.equal(body.ok, true); assert.ok(['local', 'hybrid'].includes(body.mode)); assert.equal(body.GEMINI_API_KEY, undefined);
});
test('assist returns only an approved, sourced answer', async () => {
  const r = await post({ text: 'enna documents venum' }); const data = await r.json();
  assert.equal(r.status, 200); assert.equal(data.intent, 'documents'); assert.equal(data.mode, 'local');
  assert.equal(new URL(data.answer.source).hostname, 'www.pmuy.gov.in');
});
test('unrelated request gets a safe unknown response', async () => {
  const r = await post({ text: 'compose a chocolate cake recipe' }); const data = await r.json(); assert.equal(data.intent, 'unknown'); assert.equal(data.answer, null);
});
test('empty question is rejected', async () => assert.equal((await post({ text: '' })).status, 400));
test('question must be a string', async () => assert.equal((await post({ text: {} })).status, 400));
test('long question is rejected', async () => assert.equal((await post({ text: 'a'.repeat(501) })).status, 400));
test('oversized JSON is rejected', async () => assert.equal((await post({ text: 'a'.repeat(5000) })).status, 413));
test('malformed JSON is rejected', async () => {
  const r = await fetch(`${base}/api/assist`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{' }); assert.equal(r.status, 400);
});
test('numeric identifiers are never echoed by the API', async () => {
  const r = await post({ text: 'aadhaar 123456789012 sollanuma' }); assert.doesNotMatch(await r.text(), /123456789012/);
});
test('source code, dot-env and path traversal are not public', async () => {
  assert.equal((await fetch(`${base}/server.mjs`)).status, 404);
  assert.equal((await fetch(`${base}/.env`)).status, 404);
  assert.equal((await fetch(`${base}/..%2Fserver.mjs`)).status, 403);
});
test('HEAD works for static assets', async () => { const r = await fetch(`${base}/style.css`, { method: 'HEAD' }); assert.equal(r.status, 200); assert.equal(await r.text(), ''); });
test('unapproved static HTTP methods are rejected', async () => assert.equal((await fetch(base, { method: 'DELETE' })).status, 405));

// Test the external-AI contract with a fake transport, not a real paid provider.
async function mockExternal(fn, response) {
  const oldKey = process.env.GEMINI_API_KEY;
  const realFetch = globalThis.fetch;
  const calls = [];
  process.env.GEMINI_API_KEY = 'test-only-key';
  globalThis.fetch = (url, options) => {
    if (String(url).startsWith('https://generativelanguage.googleapis.com/')) {
      calls.push(JSON.parse(options.body));
      return response();
    }
    return realFetch(url, options);
  };
  try { await fn(calls); } finally { globalThis.fetch = realFetch; if (oldKey === undefined) delete process.env.GEMINI_API_KEY; else process.env.GEMINI_API_KEY = oldKey; }
}
const modelResponse = intent => Promise.resolve(new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify({ intent }) }] } }] }), { status: 200 }));
test('configured external AI is not called without explicit consent flag', async () => {
  await mockExternal(async calls => {
    const r = await post({ text: 'an unfamiliar chocolate recipe' });
    assert.equal((await r.json()).intent, 'unknown'); assert.equal(calls.length, 0);
  }, () => modelResponse('documents'));
});
test('external intent contract sends redacted question only and returns curated facts', async () => {
  await mockExternal(async calls => {
    const r = await post({ text: 'unfamiliar query 123456789012 me@example.com', allowExternal: true });
    const data = await r.json(); assert.equal(data.intent, 'documents'); assert.equal(data.mode, 'hybrid');
    assert.equal(calls.length, 1); const sent = calls[0];
    assert.doesNotMatch(JSON.stringify(sent), /123456789012|me@example.com/);
    assert.equal(sent.contents.length, 1); assert.equal(sent.contents[0].parts.length, 1);
    assert.equal(data.answer.source, 'https://www.pmuy.gov.in/ujjwala2.html');
  }, () => modelResponse('documents'));
});
test('external unapproved intent or invented facts are ignored', async () => {
  await mockExternal(async () => {
    const r = await post({ text: 'unfamiliar random question', allowExternal: true }); const data = await r.json();
    assert.equal(data.intent, 'unknown'); assert.equal(data.answer, null);
  }, () => modelResponse('guaranteed_approval'));
});
test('external provider failure falls back without exposing errors or keys', async () => {
  await mockExternal(async () => {
    const r = await post({ text: 'unfamiliar random question', allowExternal: true }); const data = await r.json();
    assert.equal(data.mode, 'local'); assert.equal(data.intent, 'unknown'); assert.equal(data.error, undefined);
  }, () => Promise.reject(new Error('provider unavailable')));
});
